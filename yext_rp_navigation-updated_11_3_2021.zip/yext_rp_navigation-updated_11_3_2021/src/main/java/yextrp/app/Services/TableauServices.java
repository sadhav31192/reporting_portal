/**
 * @author Sandip Adhav
 */
package yextrp.app.Services;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import yextrp.app.Repository.TableauProjectRepository;
import yextrp.app.Repository.TableauUserRepository;
import yextrp.app.Repository.TableauWorkbookRepository;
import yextrp.app.entity.TableauProject;
import yextrp.app.entity.TableauUser;
import yextrp.app.entity.TableauWorkbook;

/**
 * @author Sandip Adhav
 *Tableau related Servicesto access tableau Metadata APIs by using Rest Template 
 *example. getting all users data, projects/folders data, Workbooks/Report data
 */
@Service
public class TableauServices {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	TableauUser user;
	@Autowired
	TableauUserRepository tableauUserRepository;
	@Autowired
	TableauProjectRepository tableauProjectRepository;
	@Autowired
	TableauProject tableauProject;
	@Autowired
	TableauWorkbook tableauWorkbook;
	@Autowired
	TableauWorkbookRepository tableauWorkbookRepository;

	public HashMap<Object, Object> connectToTableau() throws JsonMappingException, JsonProcessingException {
		String userCredentials = "<?xml version=\"1.0\" encoding=\"utf-8\"?><tsRequest> <credentials name=\"bi-reports@yext.com\" password=\"Bireportpass@01\" ><site contentUrl=\"yextanalytics\" /></credentials></tsRequest>";
		String connectionUrl = "https://prod-useast-a.online.tableau.com/api/3.9/auth/signin";
		HttpHeaders postHeaders = new HttpHeaders();
		postHeaders.setContentType(MediaType.APPLICATION_XML);
		HttpEntity<String> request = new HttpEntity<String>(userCredentials, postHeaders);
		ResponseEntity<JSONObject> response = restTemplate.exchange(connectionUrl, HttpMethod.POST, request,JSONObject.class);
		HashMap<Object, Object> responseHashMapObj = (HashMap<Object, Object>) new ObjectMapper().readValue(response.getBody().toString(), Object.class);
		HashMap<Object, Object> credentials = (HashMap<Object, Object>) responseHashMapObj.get("credentials");

		return credentials;
	}

	public void SaveAllUsersData(String token, String url) throws JsonMappingException, JsonProcessingException {

		int itr = 1;
		int count = 0;
		int a = 1;
		while (itr > 0) {
			String tableauUsersDataUrl = url + a;
			HttpHeaders getHeaders = new HttpHeaders();
			getHeaders.add("X-Tableau-Auth", token);
			HttpEntity<String> entity = new HttpEntity<String>(getHeaders);
			ResponseEntity<JSONObject> userData = restTemplate.exchange(tableauUsersDataUrl, HttpMethod.GET, entity,JSONObject.class);
			HashMap<Object, Object> userDataObj = (HashMap<Object, Object>) new ObjectMapper().readValue(userData.getBody().toString(), Object.class);
			HashMap<Object, Object> pagination = (HashMap<Object, Object>) userDataObj.get("pagination");
			Integer pageNumber = Integer.parseInt((String) pagination.get("pageNumber"));
			int pagesize = Integer.parseInt((String) pagination.get("pageSize"));
			int totalAvailable = Integer.parseInt((String) pagination.get("totalAvailable"));
			int iteration = Math.round(totalAvailable / pagesize) + 1;
			HashMap<Object, Object> users = (HashMap<Object, Object>) userDataObj.get("users");
			List<Object> usersMap = (List<Object>) users.get("user");
			for (Object object : usersMap) {
				HashMap<String, String> userMap = (HashMap<String, String>) object;
				user.setUserId(userMap.get("id"));
				user.setName(userMap.get("name"));
				user.setSiteRole(userMap.get("siteRole"));
				user.setAuthSetting(userMap.get("authSetting"));
				user.setExternalAuthUserId(userMap.get("externalAuthUserId"));
				user.setLastLogin(userMap.get("lastLogin"));
				user.setLanguage(userMap.get("language"));
				count++;
			}
			// System.out.println("Iteration =" + iteration);
			itr = iteration - pageNumber;
			a++;
		}
		// System.out.println(count);
	}

	public void saveUserGroupData(String token, String url) throws JsonMappingException, JsonProcessingException {
		int itr = 1;
		int count = 0;
		int a = 1;
		while (itr > 0) {
			String tableauUserGroupsDataUrl = url + a;
			HttpHeaders getHeaders = new HttpHeaders();
			getHeaders.add("X-Tableau-Auth", token);
			HttpEntity<String> entity = new HttpEntity<String>(getHeaders);
			ResponseEntity<JSONObject> userGroupsData = restTemplate.exchange(tableauUserGroupsDataUrl, HttpMethod.GET,entity, JSONObject.class);
			HashMap<Object, Object> userGroupDataObj = (HashMap<Object, Object>) new ObjectMapper().readValue(userGroupsData.getBody().toString(), Object.class);
			HashMap<Object, Object> pagination = (HashMap<Object, Object>) userGroupDataObj.get("pagination");
			Integer pageNumber = Integer.parseInt((String) pagination.get("pageNumber"));
			int pagesize = Integer.parseInt((String) pagination.get("pageSize"));
			int totalAvailable = Integer.parseInt((String) pagination.get("totalAvailable"));
			int iteration = Math.round(totalAvailable / pagesize) + 1;
			HashMap<Object, Object> groups = (HashMap<Object, Object>) userGroupDataObj.get("groups");
			List<Object> usergroupsList = (List<Object>) groups.get("group");
			for (Object object : usergroupsList) {
				HashMap<String, String> groupMap = (HashMap<String, String>) object;
				String groupId = groupMap.get("id");
				String groupName = groupMap.get("name");
				if(!groupName.equals("All Users")) {
					SaveUserByGroupId(token, groupId, groupName);
				}
				count++;
			}

			// System.out.println("Iteration =" + iteration);
			itr = iteration - pageNumber;
			a++;
		}
		//System.out.println(count);

	}

	public void SaveUserByGroupId(String token, String groupId, String groupName) throws JsonMappingException, JsonProcessingException {
		String url = "https://prod-useast-a.online.tableau.com/api/3.9/sites/422cd704-a0a0-423e-b863-864a294e51d6/groups/"+ groupId + "/users?pageNumber=";
		int itr = 1;
		int count = 0;
		int a = 1;
		int nullcount = 0;
		int iteration = 0;
		int pageNumber = 0;
		List<TableauUser> tableauUsers = new ArrayList<TableauUser>();
		while (itr > 0) {
			try {
				String tableauUsersDataUrl = url + a;
				HttpHeaders getHeaders = new HttpHeaders();
				getHeaders.add("X-Tableau-Auth", token);
				HttpEntity<String> entity = new HttpEntity<String>(getHeaders);
				ResponseEntity<JSONObject> userData = restTemplate.exchange(tableauUsersDataUrl, HttpMethod.GET, entity,JSONObject.class);
				HashMap<Object, Object> userDataObj = (HashMap<Object, Object>) new ObjectMapper().readValue(userData.getBody().toString(), Object.class);
				HashMap<Object, Object> pagination = (HashMap<Object, Object>) userDataObj.get("pagination");
				pageNumber = Integer.parseInt((String) pagination.get("pageNumber"));
				int pagesize = Integer.parseInt((String) pagination.get("pageSize"));
				int totalAvailable = Integer.parseInt((String) pagination.get("totalAvailable"));
				iteration = Math.round(totalAvailable / pagesize) + 1;
				HashMap<Object, Object> users = (HashMap<Object, Object>) userDataObj.get("users");
				List<Object> usersMap = (List<Object>) users.get("user");
				for (Object object : usersMap) {
					HashMap<String, String> userMap = (HashMap<String, String>) object;
					user.setUserId(userMap.get("id"));
					user.setName(userMap.get("name"));
					user.setSiteRole(userMap.get("siteRole"));
					user.setAuthSetting(userMap.get("authSetting"));
					user.setExternalAuthUserId(userMap.get("externalAuthUserId"));
					user.setLastLogin(userMap.get("lastLogin"));
					user.setLanguage(userMap.get("language"));
					user.setGroupId(groupId);
					user.setGroupName(groupName);
					tableauUsers.add(user);
					tableauUserRepository.save(user);
					count++;
				}
				// System.out.println("Iteration =" + iteration);
				itr = iteration - pageNumber;
				a++;
			}

			catch (NullPointerException ex) {
				itr = iteration - pageNumber;
				a++;
				count++;
				nullcount++;
			}
		}
		System.out.println("total count = " + count);
		System.out.println(tableauUsers);
		System.out.println(tableauUsers.size());
	}

	public void saveProjects(String token, String url) throws JsonMappingException, JsonProcessingException {
		int itr = 1;
		int count = 0;
		int a = 1;
		while (itr > 0) {
			String tableauProjectsDataUrl = url + a;
			HttpHeaders getHeaders = new HttpHeaders();
			getHeaders.add("X-Tableau-Auth", token);
			HttpEntity<String> entity = new HttpEntity<String>(getHeaders);
			ResponseEntity<JSONObject> projectsData = restTemplate.exchange(tableauProjectsDataUrl, HttpMethod.GET,entity, JSONObject.class);
			HashMap<Object, Object> projectDataObj = (HashMap<Object, Object>) new ObjectMapper().readValue(projectsData.getBody().toString(), Object.class);
			HashMap<Object, Object> pagination = (HashMap<Object, Object>) projectDataObj.get("pagination");
			Integer pageNumber = Integer.parseInt((String) pagination.get("pageNumber"));
			int pagesize = Integer.parseInt((String) pagination.get("pageSize"));
			int totalAvailable = Integer.parseInt((String) pagination.get("totalAvailable"));
			int iteration = Math.round(totalAvailable / pagesize) + 1;
			HashMap<Object, Object> projects = (HashMap<Object, Object>) projectDataObj.get("projects");
			ArrayList<Object> projectsList = (ArrayList<Object>) projects.get("project");
			for (Object object : projectsList) {
				@SuppressWarnings("unchecked")
				HashMap<Object, Object> projectMap = (HashMap<Object, Object>) object;
				tableauProject.setProjectId((String) projectMap.get("id"));
				tableauProject.setProjectName((String) projectMap.get("name"));
				tableauProject.setCreatedAt((String) projectMap.get("createdAt"));
				tableauProject.setUpdatedAt((String) projectMap.get("updatedAt"));
				tableauProject.setContentPermissions((String) projectMap.get("contentPermissions"));
				tableauProject.setParentProjectId((String) projectMap.get("parentProjectId"));
				HashMap<Object, Object> owner = (HashMap<Object, Object>) projectMap.get("owner");
				tableauProject.setOwnerId((String) owner.get("id"));
				System.out.println(projectMap.get("createdAt").getClass());
				tableauProjectRepository.save(tableauProject);
				count++;
			}
			// System.out.println("Iteration =" + iteration);
			itr = iteration - pageNumber;
			a++;
		}
		System.out.println("count = " + count);
	}

	public void saveWorkbooks(String token, String url) throws JsonMappingException, JsonProcessingException {
		System.out.println("inside");
		int itr = 1;
		int count = 0;
		int a = 1;
		while (itr > 0) {
			String tableauWorkbooksDataUrl = url + a;
			HttpHeaders getHeaders = new HttpHeaders();
			getHeaders.add("X-Tableau-Auth", token);
			HttpEntity<String> entity = new HttpEntity<String>(getHeaders);
			ResponseEntity<JSONObject> workbooksData = restTemplate.exchange(tableauWorkbooksDataUrl, HttpMethod.GET,entity, JSONObject.class);
			HashMap<Object, Object> workbooksDataObj = (HashMap<Object, Object>) new ObjectMapper().readValue(workbooksData.getBody().toString(), Object.class);
			HashMap<Object, Object> pagination = (HashMap<Object, Object>) workbooksDataObj.get("pagination");
			Integer pageNumber = Integer.parseInt((String) pagination.get("pageNumber"));
			int pagesize = Integer.parseInt((String) pagination.get("pageSize"));
			int totalAvailable = Integer.parseInt((String) pagination.get("totalAvailable"));
			int iteration = Math.round(totalAvailable / pagesize) + 1;
			HashMap<Object, Object> workbooks = (HashMap<Object, Object>) workbooksDataObj.get("workbooks");
			ArrayList<Object> workbooksList = (ArrayList<Object>) workbooks.get("workbook");			
			for (Object object : workbooksList){
				HashMap<Object, Object> workbookMap = (HashMap<Object,Object>) object;
				HashMap<Object, Object> project=(HashMap<Object, Object>) workbookMap.get("project");
				HashMap<Object, Object> owner=(HashMap<Object, Object>) workbookMap.get("owner");
				HashMap<Object, Object> tags=(HashMap<Object, Object>) workbookMap.get("tags");
				HashMap<Object, Object> dataAccelerationConfig=(HashMap<Object, Object>) workbookMap.get("dataAccelerationConfig");
				tableauWorkbook.setProjectId((String) project.get("id"));
				tableauWorkbook.setProjectName((String) project.get("name"));
				tableauWorkbook.setOwnerId((String) owner.get("id"));
				tableauWorkbook.setOwnerName((String) owner.get("name"));
				tableauWorkbook.setWorkbookId((String) workbookMap.get("id"));
				tableauWorkbook.setWorkbookName((String) workbookMap.get("name"));
				tableauWorkbook.setDescription((String)workbookMap.get("description"));
				tableauWorkbook.setContentUrl((String) workbookMap.get("contentUrl"));
				tableauWorkbook.setWebpageUrl((String) workbookMap.get("webpageUrl"));
				tableauWorkbook.setShowTabs((String) workbookMap.get("showTabs"));
				tableauWorkbook.setSize((String) workbookMap.get("size"));
				tableauWorkbook.setCreatedAt((String) workbookMap.get("createdAt"));
				tableauWorkbook.setUpdatedAt((String) workbookMap.get("updatedAt"));
				tableauWorkbook.setEncryptExtracts((String) workbookMap.get("encryptExtracts"));
				tableauWorkbook.setDefaultViewId((String) workbookMap.get("defaultViewId"));
				System.out.println(tableauWorkbook.getProjectId()+"---"+tableauWorkbook.getProjectName() );
				String parent1=tableauProjectRepository.getParentProject(tableauWorkbook.getProjectId());
				tableauWorkbookRepository.save(tableauWorkbook); 
				count++;
			}		 
			// System.out.println("Iteration =" + iteration);
			itr = iteration - pageNumber;
			a++;
		}
		System.out.println("count = " + count);
	}
}

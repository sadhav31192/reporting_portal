/**
 * @author Sandip Adhav
 */
package yextrp.app.Services;
import java.util.ArrayList;

import javax.jws.soap.SOAPBinding.Use;

import org.springframework.beans.factory.annotation.Autowired;
/*import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.saml.SAMLCredential;*/
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;

import yextrp.app.Repository.TableauUserRepository;
import yextrp.app.Repository.UserAccessRepository;
/**
 * @author Sandip Adhav
 *Tableau Users Related Services like get logged in user, get logged in users group
 */
@Service
public class UserServices {
	@Autowired
	TableauUserRepository tableauUserRepository; 
	@Autowired
	UserAccessRepository userAccessRepository;
	
	/*
	 * public String getLoggedInUser() { Authentication auth =
	 * SecurityContextHolder.getContext().getAuthentication(); SAMLCredential
	 * credentials = (SAMLCredential) auth.getCredentials(); String
	 * username=credentials.getNameID().getValue(); return username; }
	 * 
	 * public String getLoggedinUserGroup() { String username=getLoggedInUser();
	 * System.out.println(username); return
	 * tableauUserRepository.findUserGroupByUsername(username); }
	 */
	
	public ArrayList<String> getUserAccess(String userId) {
		return userAccessRepository.findUserAccess(userId);
		
	}
	
	
}
package yextrp.app;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.client.RestTemplate;
/**
 * Application starter class
 * @author Sandip Adhav
 *
 */

@SpringBootApplication
public class YextReportingPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(YextReportingPortalApplication.class, args);
	}
	@Bean
	   public RestTemplate getRestTemplate() { 	 		
	      return new RestTemplate();
	   }
	@Bean
	public ModelMapper modelMapper() {
	    return new ModelMapper();
	}
	
}



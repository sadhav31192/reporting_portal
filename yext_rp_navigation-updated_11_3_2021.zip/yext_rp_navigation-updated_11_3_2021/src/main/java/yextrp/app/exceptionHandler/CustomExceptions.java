/**
 * @author Sandip Adhav
 */
package yextrp.app.exceptionHandler;

/**
 * @author Sandip Adhav
 *
 */
public class CustomExceptions {
	// 
	public static class DataNotFoundException extends Exception {
		private String message;
		private static final long serialVersionUID =3555714415375055302L;
		public DataNotFoundException(String msg) {
			this.message=msg;
		} 
		public String getMessage(){
			return message;
		}
	}
	
}


/**
 * @author Sandip Adhav
 */
package yextrp.app.exceptionHandler;

import java.util.ArrayList;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import yextrp.app.entity.ResponseDTO;


/**
 * @author Sandip Adhav
 *
 */
@SuppressWarnings({"unchecked","rawtypes"})
@ControllerAdvice
public class AnnouncementsExceptionHelper{
	
	  @ExceptionHandler (CustomExceptions.DataNotFoundException.class) 
	  public ResponseEntity<Object> handleException(CustomExceptions.DataNotFoundException ex) {
		    List<String> details= new ArrayList<String>();
		    details.add(ex.getLocalizedMessage());
		    ResponseDTO dto=new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),ex.getMessage(),details);
		    return  new ResponseEntity( dto,HttpStatus.INTERNAL_SERVER_ERROR);
	  }
	  
	  @ExceptionHandler(MethodArgumentNotValidException.class)
	  public ResponseEntity<Object> handleValidationExceptions(
	    MethodArgumentNotValidException ex) {
	      System.out.println("succeed");
	      List<String> details = new ArrayList<>();
	        for(ObjectError error : ex.getBindingResult().getAllErrors()) {
	            details.add(error.getDefaultMessage());
	        }
	      ResponseDTO dto=new ResponseDTO(HttpStatus.BAD_REQUEST.value(),"Validation Failed",details);
	      return new ResponseEntity( dto,HttpStatus.BAD_REQUEST);
	  }
}

package yextrp.app.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class WelcomeController {

	@RequestMapping({"/"})
	public String start() {
		 return "forward:/index.html";
		
	}
}

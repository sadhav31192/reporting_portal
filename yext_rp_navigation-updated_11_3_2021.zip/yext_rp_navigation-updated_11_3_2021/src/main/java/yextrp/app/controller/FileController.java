package yextrp.app.controller;

import java.util.HashMap;
import java.util.List;

import org.json.simple.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import yextrp.app.Services.TableauServices;




@RestController
public class FileController {
	
	
	
	@GetMapping("/viewPdf")
	public ResponseEntity<Resource> viewPdf() {

		System.out.println("viewPdf controller called");
		Resource rs = new ClassPathResource("sample.pdf");

		// File file = new File();

		HttpHeaders header = new HttpHeaders();
		header.add(HttpHeaders.CONTENT_DISPOSITION, "inline;filename=Dummy.pdf");

		/*
		 * Path path = Paths.get(file.getAbsolutePath());
		 * 
		 * ByteArrayResource resource = null; try { resource = new
		 * ByteArrayResource(Files.readAllBytes(path)); } catch (IOException e) { //
		 * TODO Auto-generated catch block e.printStackTrace(); }
		 */

		return ResponseEntity.ok().headers(header).contentType(MediaType.parseMediaType("application/pdf")).body(rs);

	}

	
	
	
}

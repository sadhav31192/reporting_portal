/**
 * @author Sandip Adhav
 */
package yextrp.app.controller;

import java.sql.SQLDataException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import javax.validation.Valid;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.ObjectError;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import yextrp.app.Repository.AnnouncementsMetadataRepository;
import yextrp.app.entity.AnnouncementsMetadata;
import yextrp.app.entity.AnnouncementsMetadataDTO;
import yextrp.app.entity.ResponseDTO;
import yextrp.app.entity.TrainingsMetadata;
import yextrp.app.entity.TrainingsMetadataDTO;
import yextrp.app.exceptionHandler.CustomExceptions;


/**
 * @author Sandip Adhav
 * Announcements Metadata Rest APIs
 */
@RequestMapping("/announcements")
@RestController
public class AnnouncementsController {
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	AnnouncementsMetadataRepository announcementsMetadataRepository;
	@Autowired
	private Environment env;
	
	/**
	 * API to add Announcements Metadata
	 * @param announcementsMetadata
	 * @return Boolean value
	 * @throws AnnouncementNotFound 
	 */
	@PostMapping("/addAnnouncement")
	public ResponseEntity<Object> addAnnouncement(@Valid @RequestBody AnnouncementsMetadata announcementsMetadata) {
	try {
		announcementsMetadataRepository.save(announcementsMetadata); 	
		return new ResponseEntity<Object>(announcementsMetadata, HttpStatus.OK);
	}
	catch(Exception ex){
		List<String> details = new ArrayList<>();
		details.add(ex.getLocalizedMessage());
		ResponseDTO dto=new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Validation Failed",details);
		return new ResponseEntity( dto,HttpStatus.INTERNAL_SERVER_ERROR);
	}
		
	} 
		
	/**
	 *  API to access the Announcements Metadata	
	 * @return all Announcements Metadata 
	 * @throws AnnouncementNotFoundException 
	 */
	@GetMapping(path="/getAnnouncements", produces = "application/json")
	public ResponseEntity<Object> getAnnouncements() throws Exception{
		String url=env.getProperty("iconLink.path.announcements");
		ArrayList<AnnouncementsMetadata> listOfAnnouncements=(ArrayList<AnnouncementsMetadata>) announcementsMetadataRepository.findAnnouncements();  	
		if(listOfAnnouncements.isEmpty()){
			throw new CustomExceptions.DataNotFoundException("Announcements Data is Empty");
		}
		ArrayList<AnnouncementsMetadataDTO> listofAnnouncementsMetadataDTOs=new ArrayList<AnnouncementsMetadataDTO>();
		for (AnnouncementsMetadata announcementsMetadata : listOfAnnouncements) {
			AnnouncementsMetadataDTO announcementsMetadataDTO  = modelMapper.map(announcementsMetadata, AnnouncementsMetadataDTO.class);  
			String announcementType=announcementsMetadataDTO.getAnnouncementType();
			announcementsMetadataDTO.setIconLink(url+announcementType.toLowerCase().replaceAll(" ","")+".png");
			listofAnnouncementsMetadataDTOs.add(announcementsMetadataDTO);	
		}
		return new ResponseEntity<Object>(listofAnnouncementsMetadataDTOs,HttpStatus.OK);	
	} 		
}

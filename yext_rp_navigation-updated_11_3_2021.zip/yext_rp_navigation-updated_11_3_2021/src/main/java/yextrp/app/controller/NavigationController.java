/**
 * @author Sandip Adhav
 */
package yextrp.app.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.concurrent.CopyOnWriteArrayList;

import javax.xml.bind.JAXBException;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.xml.sax.SAXException;
import yextrp.app.Repository.NavigationMetadataRepository;
import yextrp.app.Services.UserServices;
import yextrp.app.entity.Category;
import yextrp.app.entity.NavigationMetadata;
import yextrp.app.entity.NavigationMetadataDTO;
import yextrp.app.entity.ReportFolderDTO;
import yextrp.app.entity.SubFunctionDTO;
import yextrp.app.entity.TopFunctionDTO;

/**
 * @author Sandip Adhav
 *
 */
@RequestMapping("/navigation")
@RestController
public class NavigationController {
	@Autowired
	NavigationMetadataRepository navigationMetadataRepository;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	UserServices userServices;
	@Autowired
	private Environment env;
	/**
	 * @param reportCategory
	 * @return
	 */
	@PostMapping("/addNavigation")
	public Boolean addNavigation(@RequestBody NavigationMetadata navigationMetadata) {
		navigationMetadataRepository.save(navigationMetadata);
		return true;
	}
	
	/**
	 * returning list of navigation data according to user group/folderids
	 * @return List of Navigation Data
	 * @throws JAXBException 
	 * @throws SAXException 
	 */
	/*@GetMapping("/getNavigation")
	public Collection<ReportFolderDTO> getNavigation() throws SAXException, JAXBException {
		String userId = "snigade";
		ArrayList<String> listofFolderIds =userServices.getUserAccess(userId);
	    String url=env.getProperty("iconLink.path.navigations");
		ArrayList<NavigationMetadata> listOfNavigationMetadata = (ArrayList<NavigationMetadata>) navigationMetadataRepository
				.findNavigationMetadata(listofFolderIds);
		ArrayList<NavigationMetadataDTO> listOfNavigationMetadataDTOs = new ArrayList<NavigationMetadataDTO>();		
		for (NavigationMetadata navigationMetadata : listOfNavigationMetadata) {
			NavigationMetadataDTO  navigationMetadataDTO=new NavigationMetadataDTO();     
			navigationMetadataDTO.setReportFolderName(navigationMetadata.getSource());
			navigationMetadataDTO.setTopFunction(navigationMetadata.getTopFunction());
			navigationMetadataDTO.setSubFunction(navigationMetadata.getSubFunction());
			navigationMetadataDTO.setCategory(navigationMetadata.getCategory());
			navigationMetadataDTO.setIconLink(url+navigationMetadata.getTopFunction().toLowerCase().replaceAll(" ","")+".png");
			listOfNavigationMetadataDTOs.add(navigationMetadataDTO);
		}
		CopyOnWriteArrayList<ReportFolderDTO> listOfReportFolderResponse = new CopyOnWriteArrayList<ReportFolderDTO>();
		
		for (NavigationMetadataDTO navigationDTO : listOfNavigationMetadataDTOs) {
			if (listOfReportFolderResponse.isEmpty()) {
				ReportFolderDTO reportnav = new ReportFolderDTO();
				CopyOnWriteArrayList<String> categoriesList = new CopyOnWriteArrayList<String>();
				categoriesList.add(navigationDTO.getCategory());
				SubFunctionDTO sFD = new SubFunctionDTO();
				sFD.setSubFunctionName(navigationDTO.getSubFunction());
				sFD.setCategories(categoriesList);
				CopyOnWriteArrayList<SubFunctionDTO> tfList = new CopyOnWriteArrayList<SubFunctionDTO>();
				tfList.add(sFD);
				TopFunctionDTO tfDto = new TopFunctionDTO();
				tfDto.setTopFunctionName(navigationDTO.getTopFunction());
				tfDto.setSubFunctions(tfList);
                tfDto.setIconLink(navigationDTO.getIconLink());
				CopyOnWriteArrayList<TopFunctionDTO> reportList = new CopyOnWriteArrayList<TopFunctionDTO>();
				reportList.add(tfDto);

				reportnav.setReportFolderName(navigationDTO.getReportFolderName());
				reportnav.setTopFunctions(reportList);
				listOfReportFolderResponse.add(reportnav);
			 continue;
			} 
			else {
				int flag = 0;
					for(ReportFolderDTO reportFolderDTO: listOfReportFolderResponse) {
					if (reportFolderDTO.getReportFolderName().equals(navigationDTO.getReportFolderName())) 
					{
						if(flag==0) {
						CopyOnWriteArrayList<TopFunctionDTO> topFunctionDTOList = (CopyOnWriteArrayList<TopFunctionDTO>) reportFolderDTO.getTopFunctions();
							int flag1=0;
						for (TopFunctionDTO topFunctionDTO : topFunctionDTOList) {
						
							if (topFunctionDTO.getTopFunctionName().equals(navigationDTO.getTopFunction())) 
							{
								if(flag1==0) {
									CopyOnWriteArrayList<SubFunctionDTO> subFunctionDTOList = (CopyOnWriteArrayList<SubFunctionDTO>) topFunctionDTO.getSubFunctions();
									int flag2=0;
									for(SubFunctionDTO SubFunctionDTO:subFunctionDTOList) {
										if(SubFunctionDTO.getSubFunctionName().equals(navigationDTO.getSubFunction())){
											if(flag2==0)
											{
												CopyOnWriteArrayList<String> categoriesList = new CopyOnWriteArrayList<String>();
												categoriesList.add(navigationDTO.getCategory());
												SubFunctionDTO.setCategories(categoriesList);
												flag2=1;
												flag1=1;
												flag=1;
											}											
											
										}
											
									}
									for(SubFunctionDTO SubFunctionDTO:subFunctionDTOList) {
										if(flag2==0){
											CopyOnWriteArrayList<String> categoriesList = new CopyOnWriteArrayList<String>();
											categoriesList.add(navigationDTO.getCategory());
											SubFunctionDTO sFD = new SubFunctionDTO();
											sFD.setSubFunctionName(navigationDTO.getSubFunction());
											sFD.setCategories(categoriesList);
											subFunctionDTOList.add(sFD);
											flag2=1;
											flag1=1;
											flag=1;
										}
									}						
								}//flag1									
							}
						}
						for (TopFunctionDTO topFunctionDTO : topFunctionDTOList) 	 {
								if(flag1==0)	{
								CopyOnWriteArrayList<String> categoriesList = new CopyOnWriteArrayList<String>();
								categoriesList.add(navigationDTO.getCategory());
								SubFunctionDTO sFD = new SubFunctionDTO();
								sFD.setSubFunctionName(navigationDTO.getSubFunction());
								sFD.setCategories(categoriesList);
								CopyOnWriteArrayList<SubFunctionDTO> tfList = new CopyOnWriteArrayList<SubFunctionDTO>();
								tfList.add(sFD);
								TopFunctionDTO tfDto = new TopFunctionDTO();
								tfDto.setTopFunctionName(navigationDTO.getTopFunction());
								tfDto.setSubFunctions(tfList);
								tfDto.setIconLink(navigationDTO.getIconLink());
								topFunctionDTOList.add(tfDto);
								reportFolderDTO.setTopFunctions(topFunctionDTOList);
								flag=1;
								flag1=1;
								}
							}
                           
						
						
					}//flag
						
					}
				}
					
					for(ReportFolderDTO reportFolderDTO: listOfReportFolderResponse) 
					{
					
				if(flag==0) {
							System.out.println("elsee");
						ReportFolderDTO reportnav = new ReportFolderDTO();
						CopyOnWriteArrayList<String> categoriesList = new CopyOnWriteArrayList<String>();
						categoriesList.add(navigationDTO.getCategory());

						SubFunctionDTO sFD = new SubFunctionDTO();

						sFD.setSubFunctionName(navigationDTO.getSubFunction());
						sFD.setCategories(categoriesList);

						CopyOnWriteArrayList<SubFunctionDTO> tfList = new CopyOnWriteArrayList<SubFunctionDTO>();
						tfList.add(sFD);
						TopFunctionDTO tfDto = new TopFunctionDTO();
						tfDto.setTopFunctionName(navigationDTO.getTopFunction());
						tfDto.setSubFunctions(tfList);
						tfDto.setSubFunctions(tfList);
						tfDto.setIconLink(navigationDTO.getIconLink());
						CopyOnWriteArrayList<TopFunctionDTO> reportList = new CopyOnWriteArrayList<TopFunctionDTO>();
						reportList.add(tfDto);
						reportnav.setReportFolderName(navigationDTO.getReportFolderName());
						reportnav.setTopFunctions(reportList);
						listOfReportFolderResponse.add(reportnav);	
						flag=1;
				}
					
					}
			}

		}
		return listOfReportFolderResponse;
	}*/
	
	@GetMapping("/getNavigation")
	public Collection<TopFunctionDTO> getNavigation() throws SAXException, JAXBException {
		String userId = "snigade";
		ArrayList<String> listofFolderIds =userServices.getUserAccess(userId);
	    String url=env.getProperty("iconLink.path.navigations");
		ArrayList<NavigationMetadata> listOfNavigationMetadata = (ArrayList<NavigationMetadata>) navigationMetadataRepository
				.findNavigationMetadata(listofFolderIds);
		ArrayList<NavigationMetadataDTO> listOfNavigationMetadataDTOs = new ArrayList<NavigationMetadataDTO>();		
		for (NavigationMetadata navigationMetadata : listOfNavigationMetadata) {
			NavigationMetadataDTO  navigationMetadataDTO=new NavigationMetadataDTO();     
			navigationMetadataDTO.setReportFolderName(navigationMetadata.getSource());
			navigationMetadataDTO.setTopFunction(navigationMetadata.getTopFunction());
			navigationMetadataDTO.setSubFunction(navigationMetadata.getSubFunction());
			navigationMetadataDTO.setCategory(navigationMetadata.getCategory());
			navigationMetadataDTO.setIconLink(url+navigationMetadata.getTopFunction().toLowerCase().replaceAll(" ","")+".png");
			listOfNavigationMetadataDTOs.add(navigationMetadataDTO);
		}
		CopyOnWriteArrayList<TopFunctionDTO> listOfTopFunctions = new CopyOnWriteArrayList<TopFunctionDTO>();
		
		for (NavigationMetadataDTO navigationDTO : listOfNavigationMetadataDTOs) {
			if (listOfTopFunctions.isEmpty()){
				if(!navigationDTO.getCategory().equals("N/A")) {
					TopFunctionDTO reportnav = new TopFunctionDTO();
					CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
					reportFoldersList.add(navigationDTO.getReportFolderName());
					Category ct=new Category();
					ct.setReportFolders(reportFoldersList);
					ct.setCategoryName(navigationDTO.getCategory());
					CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
					categories.add(ct);
					SubFunctionDTO sFD = new SubFunctionDTO();
					sFD.setSubFunctionName(navigationDTO.getSubFunction());
					sFD.setCategories(categories);
					CopyOnWriteArrayList<SubFunctionDTO> sfList = new CopyOnWriteArrayList<SubFunctionDTO>();
					sfList.add(sFD);
					reportnav.setTopFunctionName(navigationDTO.getTopFunction());
					reportnav.setSubFunctions(sfList);
					reportnav.setIconLink(navigationDTO.getIconLink());    
					listOfTopFunctions.add(reportnav);
					continue;
				}
				else {
					TopFunctionDTO reportnav = new TopFunctionDTO();
					CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
					reportFoldersList.add(navigationDTO.getReportFolderName());
					Category ct=new Category();
					ct.setCategoryName(navigationDTO.getCategory());
					CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
					categories.add(ct);
					SubFunctionDTO sFD = new SubFunctionDTO();
					sFD.setSubFunctionName(navigationDTO.getSubFunction());
					sFD.setCategories(categories);
					sFD.setReportFolders(reportFoldersList);
					CopyOnWriteArrayList<SubFunctionDTO> sfList = new CopyOnWriteArrayList<SubFunctionDTO>();
					sfList.add(sFD);
					reportnav.setTopFunctionName(navigationDTO.getTopFunction());
					reportnav.setSubFunctions(sfList);
					reportnav.setIconLink(navigationDTO.getIconLink());    
					listOfTopFunctions.add(reportnav);
					continue;
			} 
			}
			else {
				int flag = 0;
					for(TopFunctionDTO topFunctionDTO: listOfTopFunctions){
					if (topFunctionDTO.getTopFunctionName().equals(navigationDTO.getTopFunction())) 
					{
						if(flag==0) {
							CopyOnWriteArrayList<SubFunctionDTO> subFunctionDTOList = (CopyOnWriteArrayList<SubFunctionDTO>) topFunctionDTO.getSubFunctions();
							int flag1=0;
						for (SubFunctionDTO subFunctionDTO : subFunctionDTOList) {
						
							if (subFunctionDTO.getSubFunctionName().equals(navigationDTO.getSubFunction())) 
							{
								if(flag1==0) {
									
									if(!navigationDTO.getCategory().equals("N/A")) {
										CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
										reportFoldersList.add(navigationDTO.getReportFolderName());
										Category ct=new Category();
										ct.setReportFolders(reportFoldersList);
										ct.setCategoryName(navigationDTO.getCategory());
										CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
										categories.add(ct);
										subFunctionDTO.setCategories(categories);
										subFunctionDTOList.add(subFunctionDTO);
										flag=1;
										flag1=1;
										continue;
									}
									else {
										CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
										reportFoldersList.add(navigationDTO.getReportFolderName());
										Category ct=new Category();
										ct.setCategoryName(navigationDTO.getCategory());
										CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
										categories.add(ct);
										subFunctionDTO.setCategories(categories);
										subFunctionDTO.setReportFolders(reportFoldersList);
										subFunctionDTOList.add(subFunctionDTO);
										flag=1;
										flag1=1;
								} 				
									flag1=1;
									flag=1;
								}//flag1									
							}
						}
						for (SubFunctionDTO subFunctionDTO : subFunctionDTOList) 	 {
								if(flag1==0){
									if(!navigationDTO.getCategory().equals("N/A")) {
										CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
										reportFoldersList.add(navigationDTO.getReportFolderName());
										Category ct=new Category();
										ct.setReportFolders(reportFoldersList);
										ct.setCategoryName(navigationDTO.getCategory());
										CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
										categories.add(ct);
										SubFunctionDTO sFD = new SubFunctionDTO();
										sFD.setSubFunctionName(navigationDTO.getSubFunction());
										sFD.setCategories(categories);
										CopyOnWriteArrayList<SubFunctionDTO> sfList = new CopyOnWriteArrayList<SubFunctionDTO>();
										sfList.add(sFD);
										topFunctionDTO.setSubFunctions(sfList);
										flag=1;
										flag1=1;
										continue;
									}
									else {
										CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
										reportFoldersList.add(navigationDTO.getReportFolderName());
										Category ct=new Category();
										ct.setCategoryName(navigationDTO.getCategory());
										CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
										categories.add(ct);
										SubFunctionDTO sFD = new SubFunctionDTO();
										sFD.setSubFunctionName(navigationDTO.getSubFunction());
										sFD.setCategories(categories);
										sFD.setReportFolders(reportFoldersList);
										CopyOnWriteArrayList<SubFunctionDTO> sfList = new CopyOnWriteArrayList<SubFunctionDTO>();
										sfList.add(sFD);
										topFunctionDTO.setSubFunctions(sfList);
										flag=1;
										flag1=1;
										continue;
								} 					
								}
							}
					}//flag
						
					}//topfunction-if
				}
					
					for(TopFunctionDTO topFunctionDTO : listOfTopFunctions) 
					{
				if(flag==0) {
					if(!navigationDTO.getCategory().equals("N/A")) {
						TopFunctionDTO reportnav = new TopFunctionDTO();
						CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
						reportFoldersList.add(navigationDTO.getReportFolderName());
						Category ct=new Category();
						ct.setReportFolders(reportFoldersList);
						ct.setCategoryName(navigationDTO.getCategory());
						CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
						categories.add(ct);
						SubFunctionDTO sFD = new SubFunctionDTO();
						sFD.setSubFunctionName(navigationDTO.getSubFunction());
						sFD.setCategories(categories);
						CopyOnWriteArrayList<SubFunctionDTO> sfList = new CopyOnWriteArrayList<SubFunctionDTO>();
						sfList.add(sFD);
						reportnav.setTopFunctionName(navigationDTO.getTopFunction());
						reportnav.setSubFunctions(sfList);
						reportnav.setIconLink(navigationDTO.getIconLink());    
						listOfTopFunctions.add(reportnav);
						flag=1;
						continue;
					}
					else {
						TopFunctionDTO reportnav = new TopFunctionDTO();
						CopyOnWriteArrayList<String> reportFoldersList = new CopyOnWriteArrayList<String>();
						reportFoldersList.add(navigationDTO.getReportFolderName());
						Category ct=new Category();
						ct.setCategoryName(navigationDTO.getCategory());
						CopyOnWriteArrayList<Category> categories = new CopyOnWriteArrayList<Category>();
						categories.add(ct);
						SubFunctionDTO sFD = new SubFunctionDTO();
						sFD.setSubFunctionName(navigationDTO.getSubFunction());
						sFD.setCategories(categories);
						sFD.setReportFolders(reportFoldersList);
						CopyOnWriteArrayList<SubFunctionDTO> sfList = new CopyOnWriteArrayList<SubFunctionDTO>();
						sfList.add(sFD);
						reportnav.setTopFunctionName(navigationDTO.getTopFunction());
						reportnav.setSubFunctions(sfList);
						reportnav.setIconLink(navigationDTO.getIconLink());    
						listOfTopFunctions.add(reportnav);
						flag=1;
						continue;
				} 	
					
				}
					
					}
				
			}

		}
		return listOfTopFunctions;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

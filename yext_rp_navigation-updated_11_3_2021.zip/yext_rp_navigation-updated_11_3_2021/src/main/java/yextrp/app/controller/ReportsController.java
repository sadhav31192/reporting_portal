package yextrp.app.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import yextrp.app.Repository.NavigationMetadataRepository;
import yextrp.app.Repository.ReportsMetadataRepository;
import yextrp.app.Services.UserServices;
import yextrp.app.entity.AnnouncementsMetadata;
import yextrp.app.entity.AnnouncementsMetadataDTO;
import yextrp.app.entity.NavigationRequest;
import yextrp.app.entity.ReportsMetadata;
import yextrp.app.entity.ReportsMetadataDTO;

/**
 * @author Sandip Adhav
 * Reports Metadata APIs
 */
@RequestMapping("/reports")
@RestController
public class ReportsController {
	@Autowired
	ReportsMetadataRepository reportsMetadataRepository;
	@Autowired
	NavigationMetadataRepository navigationMetadataRepository;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	UserServices userServices;
	@Autowired
	private Environment env;
	/**
	 * API to access the reports according to users roles and groups
	 * @return all the reports metadata according to Navigation data/folderID
	 */
	@GetMapping("/getReports")
	public Collection<ReportsMetadataDTO> getSalesReport(){
		String url=env.getProperty("iconLink.path.reports");
		String userId = "snigade";
		ArrayList<String> listOfReportFolderId =userServices.getUserAccess(userId);
		Collection<ReportsMetadata> listOfReportsMetadata=reportsMetadataRepository.findReportsByfolderId(listOfReportFolderId);
		ArrayList<ReportsMetadataDTO> listOfReportsMetadataDTO=new ArrayList<ReportsMetadataDTO>(); 
		for (ReportsMetadata reportsMetadata : listOfReportsMetadata){
			ReportsMetadataDTO reportsMetadataDTO=modelMapper.map(reportsMetadata, ReportsMetadataDTO.class);
			System.out.println(reportsMetadataDTO);
			listOfReportsMetadataDTO.add(reportsMetadataDTO);
		}
		return listOfReportsMetadataDTO;
	} 
	
}

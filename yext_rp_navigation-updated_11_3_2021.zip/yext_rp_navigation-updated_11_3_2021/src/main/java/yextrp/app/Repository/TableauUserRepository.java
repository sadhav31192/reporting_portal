/**
 * @author Sandip Adhav
 */
package yextrp.app.Repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import yextrp.app.entity.TableauUser;


/**
 * @author Sandip Adhav
 *Repository Interface to access Tableau users Data
 */
@Repository
public interface TableauUserRepository extends JpaRepository<TableauUser, Integer> {
	/**
	 * 
	 * @return String - Name of the usergroup 
	 * find user group by user name 
	 */
	@Query(value="SELECT group_name  FROM  tableau_user WHERE  name=?1 ",nativeQuery = true)
	String findUserGroupByUsername(String name);
}

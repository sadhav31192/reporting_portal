package yextrp.app.Repository;

import java.util.Collection;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import yextrp.app.entity.TrainingsId;
import yextrp.app.entity.TrainingsMetadata;

/**
 * 
 * @author Sandip Adhav
 *Repository interface to access TrainingsMetadata from DB
 */
@Repository
public interface TrainingsMetadataRepository extends JpaRepository<TrainingsMetadata,TrainingsId> {
	/**
	 *Native Query to access Trainings metadata from TRAININGS_METADATA table  by Ranking order + "SHOW_ON_TOP" table column   
	 * @return
	 */	
	@Query(value="SELECT * FROM  reporting_portal.trainings_metadata ORDER BY show_on_top DESC,added_date DESC,display_order ASC LIMIT 10 ",nativeQuery = true)
	Collection<TrainingsMetadata> findTrainingsByRank();
		
}
	
	


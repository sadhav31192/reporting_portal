/**
 * @author Sandip Adhav
 */
package yextrp.app.Repository;
import java.util.Collection;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import yextrp.app.entity.AnnouncementsId;
import yextrp.app.entity.AnnouncementsMetadata;


/**
 * Repository Interface to access AnnouncementsMetadataRepository from DB
 * @author Sandip Adhav
 *
 */
@Repository
public interface AnnouncementsMetadataRepository extends JpaRepository<AnnouncementsMetadata,AnnouncementsId> {
	
	/**
	 * Native Query to access Announcements Metadata
	 * @return
	 */
	@Query(value=" SELECT * FROM reporting_portal.announcements_metadata WHERE CURRENT_DATE >= start_date AND CURRENT_DATE <= end_date ORDER BY show_on_top DESC, display_order ASC , start_date DESC LIMIT 10",nativeQuery = true)
	Collection<AnnouncementsMetadata> findAnnouncements();
	
}
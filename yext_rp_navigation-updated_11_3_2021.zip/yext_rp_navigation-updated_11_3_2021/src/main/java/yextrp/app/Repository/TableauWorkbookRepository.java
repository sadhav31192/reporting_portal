/**
 * @author Sandip Adhav
 */
package yextrp.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import yextrp.app.entity.TableauWorkbook;

/**
 * @author Sandip Adhav
 *Repository Interface to access Tableau Workbook/Reports Data
 */
public interface TableauWorkbookRepository extends JpaRepository<TableauWorkbook,String> {
	
	
	
}

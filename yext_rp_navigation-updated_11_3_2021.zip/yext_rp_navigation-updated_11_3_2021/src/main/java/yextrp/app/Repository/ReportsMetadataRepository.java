
package yextrp.app.Repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import yextrp.app.entity.ReportsMetadata;

/**
 * Repository Interface to access ReportsMetadataRepository from DB
 * @author Sandip Adhav
 *
 */
@Repository
public interface ReportsMetadataRepository extends JpaRepository<ReportsMetadata,String> {
	
	/**
	 * Native Query to access ReportsMetadata from Table REPORTS_METADATA according to supplied list of Functions-Sub functions  
	 * @param reportFolderId
	 * @return
	 */
	@Query(value="SELECT * FROM reporting_portal.reports_metadata WHERE report_folder_id  IN ?1 ",nativeQuery = true)
	Collection<ReportsMetadata> findReportsByfolderId(ArrayList<String> listOfReportFolderId);
	
}
/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.util.List;

/**
 * @author Sandip Adhav
 *
 */
public class SubFunctionDTO {
	private String subFunctionName;
	private List<Category> categories;
	private List<String> reportFolders;
	
	public SubFunctionDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SubFunctionDTO(String subFunctionName, List<Category> categories, List<String> reportFolders) {
		super();
		this.subFunctionName = subFunctionName;
		this.categories = categories;
		this.reportFolders = reportFolders;
	}

	public String getSubFunctionName() {
		return subFunctionName;
	}

	public void setSubFunctionName(String subFunctionName) {
		this.subFunctionName = subFunctionName;
	}

	public List<Category> getCategories() {
		return categories;
	}

	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}

	public List<String> getReportFolders() {
		return reportFolders;
	}

	public void setReportFolders(List<String> reportFolders) {
		this.reportFolders = reportFolders;
	}
	
}

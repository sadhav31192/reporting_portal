/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

/**
 * @author Sandip Adhav
 *
 */
@Component
@Entity
@Table(name="TableauProject", schema = "reporting_portal")
public class TableauProject {
	@Id
	@Column
	private String projectId;
	@Column
	private String projectName;
	@Column
	private String projectOwnerId;
	@Column
	private String parentProjectId;
	@Column
	private String createdAt;
	@Column
	private String updatedAt;
	@Column
	private String contentPermissions;
    @Column
    private String ownerId;
	public TableauProject(String projectId, String projectName, String projectOwnerId, String parentProjectId,
			String createdAt, String updatedAt, String contentPermissions, String ownerId) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.projectOwnerId = projectOwnerId;
		this.parentProjectId = parentProjectId;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.contentPermissions = contentPermissions;
		this.ownerId = ownerId;
	}
	public TableauProject() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TableauProject [projectId=" + projectId + ", projectName=" + projectName + ", projectOwnerId="
				+ projectOwnerId + ", parentProjectId=" + parentProjectId + ", createdAt=" + createdAt + ", updatedAt="
				+ updatedAt + ", contentPermissions=" + contentPermissions + ", ownerId=" + ownerId + "]";
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getProjectOwnerId() {
		return projectOwnerId;
	}
	public void setProjectOwnerId(String projectOwnerId) {
		this.projectOwnerId = projectOwnerId;
	}
	public String getParentProjectId() {
		return parentProjectId;
	}
	public void setParentProjectId(String parentProjectId) {
		this.parentProjectId = parentProjectId;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}
	public String getContentPermissions() {
		return contentPermissions;
	}
	public void setContentPermissions(String contentPermissions) {
		this.contentPermissions = contentPermissions;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
    
    
	

}

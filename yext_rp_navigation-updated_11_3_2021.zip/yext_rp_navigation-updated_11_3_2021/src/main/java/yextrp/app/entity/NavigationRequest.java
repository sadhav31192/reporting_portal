/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import org.springframework.stereotype.Component;

/**
 * @author Sandip Adhav
 *
 */
@Component
public class NavigationRequest {
	private String topFunction;
	private String subFunction;
	private String category;
	private String reportFolderName;
	
	public NavigationRequest() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NavigationRequest(String topFunction, String subFunction, String category, String reportFolderName) {
		super();
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.reportFolderName = reportFolderName;
	}

	@Override
	public String toString() {
		return "NavigationRequest [topFunction=" + topFunction + ", subFunction=" + subFunction + ", category="
				+ category + ", reportFolderName=" + reportFolderName + "]";
	}

	public String getTopFunction() {
		return topFunction;
	}

	public void setTopFunction(String topFunction) {
		this.topFunction = topFunction;
	}

	public String getSubFunction() {
		return subFunction;
	}

	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getReportFolderName() {
		return reportFolderName;
	}

	public void setReportFolderName(String reportFolderName) {
		this.reportFolderName = reportFolderName;
	}
	
	
}

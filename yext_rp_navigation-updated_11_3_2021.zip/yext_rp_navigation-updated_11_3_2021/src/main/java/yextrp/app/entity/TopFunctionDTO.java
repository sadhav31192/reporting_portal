/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.util.List;

/**
 * @author Sandip Adhav
 *
 */
public class TopFunctionDTO {
	
	private String topFunctionName;
	private List<SubFunctionDTO> subFunctions;
	private String iconLink;
	
	public TopFunctionDTO() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TopFunctionDTO(String topFunctionName, List<SubFunctionDTO> subFunctions, String iconLink) {
		super();
		this.topFunctionName = topFunctionName;
		this.subFunctions = subFunctions;
		this.iconLink = iconLink;
	}

	public String getTopFunctionName() {
		return topFunctionName;
	}

	public void setTopFunctionName(String topFunctionName) {
		this.topFunctionName = topFunctionName;
	}

	public List<SubFunctionDTO> getSubFunctions() {
		return subFunctions;
	}

	public void setSubFunctions(List<SubFunctionDTO> subFunctions) {
		this.subFunctions = subFunctions;
	}

	public String getIconLink() {
		return iconLink;
	}

	public void setIconLink(String iconLink) {
		this.iconLink = iconLink;
	}
	
	
}

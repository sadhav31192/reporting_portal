/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.util.List;
/**
 * @author Sandip Adhav
 *
 */
public class ReportFolderDTO {
	private String reportFolderName;
	private List<TopFunctionDTO> topFunctions;
	public ReportFolderDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ReportFolderDTO(String reportFolderName, List<TopFunctionDTO> topFunctions) {
		super();
		this.reportFolderName = reportFolderName;
		this.topFunctions = topFunctions;
	}
	@Override
	public String toString() {
		return "ReportFolderDTO [reportFolderName=" + reportFolderName + ", topFunctions=" + topFunctions + "]";
	}
	public String getReportFolderName() {
		return reportFolderName;
	}
	public void setReportFolderName(String reportFolderName) {
		this.reportFolderName = reportFolderName;
	}
	public List<TopFunctionDTO> getTopFunctions() {
		return topFunctions;
	}
	public void setTopFunctions(List<TopFunctionDTO> topFunctions) {
		this.topFunctions = topFunctions;
	}
		
}

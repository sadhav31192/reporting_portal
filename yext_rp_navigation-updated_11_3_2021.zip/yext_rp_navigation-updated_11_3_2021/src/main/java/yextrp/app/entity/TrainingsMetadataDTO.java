package yextrp.app.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
/**
 * Entity class for TrainingsMetadata
 * @author Sandip Adhav
 *
 */
@Component
public class TrainingsMetadataDTO {
	
	private String contentType;
	private String trainingSummary;
	private String trainingDetailsTooltip;
	private String trainingUrl;
	private String iconLink;
	@Override
	public String toString() {
		return "TrainingsMetadataDTO [contentType=" + contentType + ", trainingSummary=" + trainingSummary
				+ ", trainingDetailsTooltip=" + trainingDetailsTooltip + ", trainingUrl=" + trainingUrl + ", iconLink="
				+ iconLink + "]";
	}
	
	public TrainingsMetadataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public TrainingsMetadataDTO(String contentType, String trainingSummary, String trainingDetailsTooltip,
			String trainingUrl, String iconLink) {
		super();
		this.contentType = contentType;
		this.trainingSummary = trainingSummary;
		this.trainingDetailsTooltip = trainingDetailsTooltip;
		this.trainingUrl = trainingUrl;
		this.iconLink = iconLink;
	}
	public String getContentType() {
		return contentType;
	}
	public void setContentType(String contentType) {
		this.contentType = contentType;
	}
	public String getTrainingSummary() {
		return trainingSummary;
	}
	public void setTrainingSummary(String trainingSummary) {
		this.trainingSummary = trainingSummary;
	}
	public String getTrainingDetailsTooltip() {
		return trainingDetailsTooltip;
	}
	public void setTrainingDetailsTooltip(String trainingDetailsTooltip) {
		this.trainingDetailsTooltip = trainingDetailsTooltip;
	}
	public String getTrainingUrl() {
		return trainingUrl;
	}
	public void setTrainingUrl(String trainingUrl) {
		this.trainingUrl = trainingUrl;
	}
	public String getIconLink() {
		return iconLink;
	}
	public void setIconLink(String iconLink) {
		this.iconLink = iconLink;
	}
	
}

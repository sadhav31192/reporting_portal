/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * @author Sandip Adhav
 *
 */
public class NavigationMetdataId implements Serializable{
	
	private String topFunction;
	private String subFunction;
	private String category;
	private String source;
	
	public NavigationMetdataId() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public NavigationMetdataId(String topFunction, String subFunction, String category, String reportFolderName) {
		super();
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.source = source;
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((category == null) ? 0 : category.hashCode());
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		result = prime * result + ((subFunction == null) ? 0 : subFunction.hashCode());
		result = prime * result + ((topFunction == null) ? 0 : topFunction.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		NavigationMetdataId other = (NavigationMetdataId) obj;
		if (category == null) {
			if (other.category != null)
				return false;
		} else if (!category.equals(other.category))
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		if (subFunction == null) {
			if (other.subFunction != null)
				return false;
		} else if (!subFunction.equals(other.subFunction))
			return false;
		if (topFunction == null) {
			if (other.topFunction != null)
				return false;
		} else if (!topFunction.equals(other.topFunction))
			return false;
		return true;
	}
	
	
}

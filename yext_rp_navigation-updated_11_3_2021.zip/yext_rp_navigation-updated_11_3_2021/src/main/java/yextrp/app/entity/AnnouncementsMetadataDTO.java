/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import org.springframework.stereotype.Component;

/**
 * @author Sandip Adhav
 *
 */
@Component
public class AnnouncementsMetadataDTO {
	private String AnnouncementType; 
	private String AnnouncementText; 
	private String AnnouncementTooltip; 
	private String UrlForDetails; 
	private String IconLink;
	public AnnouncementsMetadataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AnnouncementsMetadataDTO(String announcementType, String announcementText, String announcementTooltip,
			String urlForDetails, String iconLink) {
		super();
		AnnouncementType = announcementType;
		AnnouncementText = announcementText;
		AnnouncementTooltip = announcementTooltip;
		UrlForDetails = urlForDetails;
		IconLink = iconLink;
	}
	@Override
	public String toString() {
		return "AnnouncementsMetadataDTO [AnnouncementType=" + AnnouncementType + ", AnnouncementText="
				+ AnnouncementText + ", AnnouncementTooltip=" + AnnouncementTooltip + ", UrlForDetails=" + UrlForDetails
				+ ", IconLink=" + IconLink + "]";
	}
	public String getAnnouncementType() {
		return AnnouncementType;
	}
	public void setAnnouncementType(String announcementType) {
		AnnouncementType = announcementType;
	}
	public String getAnnouncementText() {
		return AnnouncementText;
	}
	public void setAnnouncementText(String announcementText) {
		AnnouncementText = announcementText;
	}
	public String getAnnouncementTooltip() {
		return AnnouncementTooltip;
	}
	public void setAnnouncementTooltip(String announcementTooltip) {
		AnnouncementTooltip = announcementTooltip;
	}
	public String getUrlForDetails() {
		return UrlForDetails;
	}
	public void setUrlForDetails(String urlForDetails) {
		UrlForDetails = urlForDetails;
	}
	public String getIconLink() {
		return IconLink;
	}
	public void setIconLink(String iconLink) {
		IconLink = iconLink;
	}

	
	
}

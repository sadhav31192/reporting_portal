package yextrp.app.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
/**
 * 
 * @author Sandip Adhav
 * Entity class for ReportsMetadata
 */
@Entity
@Table(name="ReportsMetadata", schema = "reporting_portal")
public class ReportsMetadata implements Serializable {
	
	@Id
	@Column
	private String reportId;
	@Column
	private String reportName;
	@Column
	private String reportDescription;
	@Column
	private String businessOwnerIdApi;
	@Column
	private String businessOwnerNameApi;
	@Column
	private String businessOwnerEmailApi;
	@Column
	private String businessOwnerName;
	@Column
	private String businessOwnerEmail;
	@Column
	private String reportFolderId;
	@Column
	private String reportFolderName;
	@Column
	private String reportingSource;
	@Column
	private String topFunction;
	@Column
	private String subFunction;
	@Column
	private String category;
	@Column
	private String thumbnailFilenameApi;
	@Column
	private String agnosticSource;
	@Column
	private String agnosticFormat;
	@Column
	private String desktopUrl;
	@Column
	private String mobileUrl;
	@Column
	private String embeddedUrl;
	@Column
	private String reportGlossaryUrl;
	@Column
	private String dataMappingDocumentUrl;
	@Column
	private String documentName;
	@Column
	private String documentUrl;
	@Column
	private String supportTicketUrl;
	@Column
	private String soxComplianceFlag; 
	@Column
	private String boardReportingFlag;
	@Column
	private String extraFlag1;
	@Column
	private String extraFlag2;
	@Column
	private String insertDate;
	@Column
	private Date lastModifiedDate;
	@Column
	private String lastModifiedBy;
	@Column
	private String softDeleteFlag;
	
	public ReportsMetadata() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ReportsMetadata(String reportId, String reportName, String reportDescription, String businessOwnerIdApi,
			String businessOwnerNameApi, String businessOwnerEmailApi, String businessOwnerName,
			String businessOwnerEmail, String reportFolderId, String reportFolderName, String reportingSource,
			String topFunction, String subFunction, String category, String thumbnailFilenameApi, String agnosticSource,
			String agnosticFormat, String desktopUrl, String mobileUrl, String embeddedUrl, String reportGlossaryUrl,
			String dataMappingDocumentUrl, String documentName, String documentUrl, String supportTicketUrl,
			String soxComplianceFlag, String boardReportingFlag, String extraFlag1, String extraFlag2,
			String insertDate, Date lastModifiedDate, String lastModifiedBy, String softDeleteFlag) {
		super();
		this.reportId = reportId;
		this.reportName = reportName;
		this.reportDescription = reportDescription;
		this.businessOwnerIdApi = businessOwnerIdApi;
		this.businessOwnerNameApi = businessOwnerNameApi;
		this.businessOwnerEmailApi = businessOwnerEmailApi;
		this.businessOwnerName = businessOwnerName;
		this.businessOwnerEmail = businessOwnerEmail;
		this.reportFolderId = reportFolderId;
		this.reportFolderName = reportFolderName;
		this.reportingSource = reportingSource;
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.thumbnailFilenameApi = thumbnailFilenameApi;
		this.agnosticSource = agnosticSource;
		this.agnosticFormat = agnosticFormat;
		this.desktopUrl = desktopUrl;
		this.mobileUrl = mobileUrl;
		this.embeddedUrl = embeddedUrl;
		this.reportGlossaryUrl = reportGlossaryUrl;
		this.dataMappingDocumentUrl = dataMappingDocumentUrl;
		this.documentName = documentName;
		this.documentUrl = documentUrl;
		this.supportTicketUrl = supportTicketUrl;
		this.soxComplianceFlag = soxComplianceFlag;
		this.boardReportingFlag = boardReportingFlag;
		this.extraFlag1 = extraFlag1;
		this.extraFlag2 = extraFlag2;
		this.insertDate = insertDate;
		this.lastModifiedDate = lastModifiedDate;
		this.lastModifiedBy = lastModifiedBy;
		this.softDeleteFlag = softDeleteFlag;
	}

	@Override
	public String toString() {
		return "ReportsMetadata [reportId=" + reportId + ", reportName=" + reportName + ", reportDescription="
				+ reportDescription + ", businessOwnerIdApi=" + businessOwnerIdApi + ", businessOwnerNameApi="
				+ businessOwnerNameApi + ", businessOwnerEmailApi=" + businessOwnerEmailApi + ", businessOwnerName="
				+ businessOwnerName + ", businessOwnerEmail=" + businessOwnerEmail + ", reportFolderId="
				+ reportFolderId + ", reportFolderName=" + reportFolderName + ", reportingSource=" + reportingSource
				+ ", topFunction=" + topFunction + ", subFunction=" + subFunction + ", category=" + category
				+ ", thumbnailFilenameApi=" + thumbnailFilenameApi + ", agnosticSource=" + agnosticSource
				+ ", agnosticFormat=" + agnosticFormat + ", desktopUrl=" + desktopUrl + ", mobileUrl=" + mobileUrl
				+ ", embeddedUrl=" + embeddedUrl + ", reportGlossaryUrl=" + reportGlossaryUrl
				+ ", dataMappingDocumentUrl=" + dataMappingDocumentUrl + ", documentName=" + documentName
				+ ", documentUrl=" + documentUrl + ", supportTicketUrl=" + supportTicketUrl + ", soxComplianceFlag="
				+ soxComplianceFlag + ", boardReportingFlag=" + boardReportingFlag + ", extraFlag1=" + extraFlag1
				+ ", extraFlag2=" + extraFlag2 + ", insertDate=" + insertDate + ", lastModifiedDate=" + lastModifiedDate
				+ ", lastModifiedBy=" + lastModifiedBy + ", softDeleteFlag=" + softDeleteFlag + "]";
	}

	public String getReportId() {
		return reportId;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getReportDescription() {
		return reportDescription;
	}

	public void setReportDescription(String reportDescription) {
		this.reportDescription = reportDescription;
	}

	public String getBusinessOwnerIdApi() {
		return businessOwnerIdApi;
	}

	public void setBusinessOwnerIdApi(String businessOwnerIdApi) {
		this.businessOwnerIdApi = businessOwnerIdApi;
	}

	public String getBusinessOwnerNameApi() {
		return businessOwnerNameApi;
	}

	public void setBusinessOwnerNameApi(String businessOwnerNameApi) {
		this.businessOwnerNameApi = businessOwnerNameApi;
	}

	public String getBusinessOwnerEmailApi() {
		return businessOwnerEmailApi;
	}

	public void setBusinessOwnerEmailApi(String businessOwnerEmailApi) {
		this.businessOwnerEmailApi = businessOwnerEmailApi;
	}

	public String getBusinessOwnerName() {
		return businessOwnerName;
	}

	public void setBusinessOwnerName(String businessOwnerName) {
		this.businessOwnerName = businessOwnerName;
	}

	public String getBusinessOwnerEmail() {
		return businessOwnerEmail;
	}

	public void setBusinessOwnerEmail(String businessOwnerEmail) {
		this.businessOwnerEmail = businessOwnerEmail;
	}

	public String getReportFolderId() {
		return reportFolderId;
	}

	public void setReportFolderId(String reportFolderId) {
		this.reportFolderId = reportFolderId;
	}

	public String getReportFolderName() {
		return reportFolderName;
	}

	public void setReportFolderName(String reportFolderName) {
		this.reportFolderName = reportFolderName;
	}

	public String getReportingSource() {
		return reportingSource;
	}

	public void setReportingSource(String reportingSource) {
		this.reportingSource = reportingSource;
	}

	public String getTopFunction() {
		return topFunction;
	}

	public void setTopFunction(String topFunction) {
		this.topFunction = topFunction;
	}

	public String getSubFunction() {
		return subFunction;
	}

	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getThumbnailFilenameApi() {
		return thumbnailFilenameApi;
	}

	public void setThumbnailFilenameApi(String thumbnailFilenameApi) {
		this.thumbnailFilenameApi = thumbnailFilenameApi;
	}

	public String getAgnosticSource() {
		return agnosticSource;
	}

	public void setAgnosticSource(String agnosticSource) {
		this.agnosticSource = agnosticSource;
	}

	public String getAgnosticFormat() {
		return agnosticFormat;
	}

	public void setAgnosticFormat(String agnosticFormat) {
		this.agnosticFormat = agnosticFormat;
	}

	public String getDesktopUrl() {
		return desktopUrl;
	}

	public void setDesktopUrl(String desktopUrl) {
		this.desktopUrl = desktopUrl;
	}

	public String getMobileUrl() {
		return mobileUrl;
	}

	public void setMobileUrl(String mobileUrl) {
		this.mobileUrl = mobileUrl;
	}

	public String getEmbeddedUrl() {
		return embeddedUrl;
	}

	public void setEmbeddedUrl(String embeddedUrl) {
		this.embeddedUrl = embeddedUrl;
	}

	public String getReportGlossaryUrl() {
		return reportGlossaryUrl;
	}

	public void setReportGlossaryUrl(String reportGlossaryUrl) {
		this.reportGlossaryUrl = reportGlossaryUrl;
	}

	public String getDataMappingDocumentUrl() {
		return dataMappingDocumentUrl;
	}

	public void setDataMappingDocumentUrl(String dataMappingDocumentUrl) {
		this.dataMappingDocumentUrl = dataMappingDocumentUrl;
	}

	public String getDocumentName() {
		return documentName;
	}

	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	public String getDocumentUrl() {
		return documentUrl;
	}

	public void setDocumentUrl(String documentUrl) {
		this.documentUrl = documentUrl;
	}

	public String getSupportTicketUrl() {
		return supportTicketUrl;
	}

	public void setSupportTicketUrl(String supportTicketUrl) {
		this.supportTicketUrl = supportTicketUrl;
	}

	public String getSoxComplianceFlag() {
		return soxComplianceFlag;
	}

	public void setSoxComplianceFlag(String soxComplianceFlag) {
		this.soxComplianceFlag = soxComplianceFlag;
	}

	public String getBoardReportingFlag() {
		return boardReportingFlag;
	}

	public void setBoardReportingFlag(String boardReportingFlag) {
		this.boardReportingFlag = boardReportingFlag;
	}

	public String getExtraFlag1() {
		return extraFlag1;
	}

	public void setExtraFlag1(String extraFlag1) {
		this.extraFlag1 = extraFlag1;
	}

	public String getExtraFlag2() {
		return extraFlag2;
	}

	public void setExtraFlag2(String extraFlag2) {
		this.extraFlag2 = extraFlag2;
	}

	public String getInsertDate() {
		return insertDate;
	}

	public void setInsertDate(String insertDate) {
		this.insertDate = insertDate;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public String getSoftDeleteFlag() {
		return softDeleteFlag;
	}

	public void setSoftDeleteFlag(String softDeleteFlag) {
		this.softDeleteFlag = softDeleteFlag;
	}

	
}

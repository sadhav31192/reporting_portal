/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * @author Sandip Adhav
 *
 */
public class TrainingsId implements Serializable{
	private Date addedDate;
	private String contentType;
	private String trainingSummary;
	
	public TrainingsId() {	
		super();
		// TODO Auto-generated constructor stub
	}

	public TrainingsId(Date addedDate, String contentType, String trainingSummary) {
		super();
		this.addedDate = addedDate;
		this.contentType = contentType;
		this.trainingSummary = trainingSummary;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contentType == null) ? 0 : contentType.hashCode());
		result = prime * result + ((addedDate == null) ? 0 : addedDate.hashCode());
		result = prime * result + ((trainingSummary == null) ? 0 : trainingSummary.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrainingsId other = (TrainingsId) obj;
		if (contentType == null) {
			if (other.contentType != null)
				return false;
		} else if (!contentType.equals(other.contentType))
			return false;
		if (addedDate == null) {
			if (other.addedDate != null)
				return false;
		} else if (!addedDate.equals(other.addedDate))
			return false;
		if (trainingSummary == null) {
			if (other.trainingSummary != null)
				return false;
		} else if (!trainingSummary.equals(other.trainingSummary))
			return false;
		return true;
	}
		
	
}

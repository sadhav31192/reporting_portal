/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

/**
 * @author Sandip Adhav
 *
 */
public class ReportsMetadataDTO {
	private String reportName;
	private String reportDescription;
	private String desktopUrl;
	private String businessOwnerName;
	private String businessOwnerEmail;
	private String reportFolderName;
	private String topFunction;
	private String subFunction;
	private String category;
	private String embeddedUrl;
	private String editFlag;
	private String reportGlossaryUrl;
	private String editIconUrl;
	private String reportGlossaryIconUrl;
	private String embeddedIconUrl;	
	private String ownerIconUrl;
	private String queriesIconUrl;
	private String soxComplianceFlag;
	
	
	public ReportsMetadataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}


	public ReportsMetadataDTO(String reportName, String reportDescription, String desktopUrl, String businessOwnerName,
			String businessOwnerEmail, String reportFolderName, String topFunction, String subFunction, String category,
			String embeddedUrl, String editFlag, String reportGlossaryUrl, String editIconUrl,
			String reportGlossaryIconUrl, String embeddedIconUrl, String ownerIconUrl, String queriesIconUrl,
			String soxComplianceFlag) {
		super();
		this.reportName = reportName;
		this.reportDescription = reportDescription;
		this.desktopUrl = desktopUrl;
		this.businessOwnerName = businessOwnerName;
		this.businessOwnerEmail = businessOwnerEmail;
		this.reportFolderName = reportFolderName;
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.embeddedUrl = embeddedUrl;
		this.editFlag = editFlag;
		this.reportGlossaryUrl = reportGlossaryUrl;
		this.editIconUrl = editIconUrl;
		this.reportGlossaryIconUrl = reportGlossaryIconUrl;
		this.embeddedIconUrl = embeddedIconUrl;
		this.ownerIconUrl = ownerIconUrl;
		this.queriesIconUrl = queriesIconUrl;
		this.soxComplianceFlag = soxComplianceFlag;
	}


	@Override
	public String toString() {
		return "ReportsMetadataDTO [reportName=" + reportName + ", reportDescription=" + reportDescription
				+ ", desktopUrl=" + desktopUrl + ", businessOwnerName=" + businessOwnerName + ", businessOwnerEmail="
				+ businessOwnerEmail + ", reportFolderName=" + reportFolderName + ", topFunction=" + topFunction
				+ ", subFunction=" + subFunction + ", category=" + category + ", embeddedUrl=" + embeddedUrl
				+ ", editFlag=" + editFlag + ", reportGlossaryUrl=" + reportGlossaryUrl + ", editIconUrl=" + editIconUrl
				+ ", reportGlossaryIconUrl=" + reportGlossaryIconUrl + ", embeddedIconUrl=" + embeddedIconUrl
				+ ", ownerIconUrl=" + ownerIconUrl + ", queriesIconUrl=" + queriesIconUrl + ", soxComplianceFlag="
				+ soxComplianceFlag + "]";
	}


	public String getReportName() {
		return reportName;
	}


	public void setReportName(String reportName) {
		this.reportName = reportName;
	}


	public String getReportDescription() {
		return reportDescription;
	}


	public void setReportDescription(String reportDescription) {
		this.reportDescription = reportDescription;
	}


	public String getDesktopUrl() {
		return desktopUrl;
	}


	public void setDesktopUrl(String desktopUrl) {
		this.desktopUrl = desktopUrl;
	}


	public String getBusinessOwnerName() {
		return businessOwnerName;
	}


	public void setBusinessOwnerName(String businessOwnerName) {
		this.businessOwnerName = businessOwnerName;
	}


	public String getBusinessOwnerEmail() {
		return businessOwnerEmail;
	}


	public void setBusinessOwnerEmail(String businessOwnerEmail) {
		this.businessOwnerEmail = businessOwnerEmail;
	}


	public String getReportFolderName() {
		return reportFolderName;
	}


	public void setReportFolderName(String reportFolderName) {
		this.reportFolderName = reportFolderName;
	}


	public String getTopFunction() {
		return topFunction;
	}


	public void setTopFunction(String topFunction) {
		this.topFunction = topFunction;
	}


	public String getSubFunction() {
		return subFunction;
	}


	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getEmbeddedUrl() {
		return embeddedUrl;
	}


	public void setEmbeddedUrl(String embeddedUrl) {
		this.embeddedUrl = embeddedUrl;
	}


	public String getEditFlag() {
		return editFlag;
	}


	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}


	public String getReportGlossaryUrl() {
		return reportGlossaryUrl;
	}


	public void setReportGlossaryUrl(String reportGlossaryUrl) {
		this.reportGlossaryUrl = reportGlossaryUrl;
	}


	public String getEditIconUrl() {
		return editIconUrl;
	}


	public void setEditIconUrl(String editIconUrl) {
		this.editIconUrl = editIconUrl;
	}


	public String getReportGlossaryIconUrl() {
		return reportGlossaryIconUrl;
	}


	public void setReportGlossaryIconUrl(String reportGlossaryIconUrl) {
		this.reportGlossaryIconUrl = reportGlossaryIconUrl;
	}


	public String getEmbeddedIconUrl() {
		return embeddedIconUrl;
	}


	public void setEmbeddedIconUrl(String embeddedIconUrl) {
		this.embeddedIconUrl = embeddedIconUrl;
	}


	public String getOwnerIconUrl() {
		return ownerIconUrl;
	}


	public void setOwnerIconUrl(String ownerIconUrl) {
		this.ownerIconUrl = ownerIconUrl;
	}


	public String getQueriesIconUrl() {
		return queriesIconUrl;
	}


	public void setQueriesIconUrl(String queriesIconUrl) {
		this.queriesIconUrl = queriesIconUrl;
	}


	public String getSoxComplianceFlag() {
		return soxComplianceFlag;
	}


	public void setSoxComplianceFlag(String soxComplianceFlag) {
		this.soxComplianceFlag = soxComplianceFlag;
	}
	
	
	
	
	

		
		
}

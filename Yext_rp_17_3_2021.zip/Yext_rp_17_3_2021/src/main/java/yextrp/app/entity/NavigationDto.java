package yextrp.app.entity;

import java.util.List;

public class NavigationDto{
    public String topFunctionName;
    public List<SubFunction> subFunctions;
    public String iconLink;
	public NavigationDto(String topFunctionName, List<SubFunction> subFunctions, String iconLink) {
		super();
		this.topFunctionName = topFunctionName;
		this.subFunctions = subFunctions;
		this.iconLink = iconLink;
	}
	public NavigationDto() {
		super();
		// TODO Auto-generated constructor stub
	}
	public String getTopFunctionName() {
		return topFunctionName;
	}
	public void setTopFunctionName(String topFunctionName) {
		this.topFunctionName = topFunctionName;
	}
	public List<SubFunction> getSubFunctions() {
		return subFunctions;
	}
	public void setSubFunctions(List<SubFunction> subFunctions) {
		this.subFunctions = subFunctions;
	}
	public String getIconLink() {
		return iconLink;
	}
	public void setIconLink(String iconLink) {
		this.iconLink = iconLink;
	}
    
    
}
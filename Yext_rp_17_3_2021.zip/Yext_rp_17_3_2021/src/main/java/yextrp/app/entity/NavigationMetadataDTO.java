/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import javax.persistence.Column;
import javax.persistence.Id;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;

/**
 * @author Sandip Adhav
 *
 */
@Component
public class NavigationMetadataDTO {
	private String topFunction;
	private String subFunction;
	private String category;
	private String reportFolderName;
	private String navigationFlag;
	private String iconLink;
	public NavigationMetadataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NavigationMetadataDTO(String topFunction, String subFunction, String category, String reportFolderName,
			String navigationFlag, String iconLink) {
		super();
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.reportFolderName = reportFolderName;
		this.navigationFlag = navigationFlag;
		this.iconLink = iconLink;
	}
	
	@Override
	public String toString() {
		return "NavigationMetadataDTO [topFunction=" + topFunction + ", subFunction=" + subFunction + ", category="
				+ category + ", reportFolderName=" + reportFolderName + ", navigationFlag=" + navigationFlag
				+ ", iconLink=" + iconLink + "]";
	}
	
	public String getTopFunction() {
		return topFunction;
	}
	public void setTopFunction(String topFunction) {
		this.topFunction = topFunction;
	}
	public String getSubFunction() {
		return subFunction;
	}
	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	
	public String getReportFolderName() {
		return reportFolderName;
	}
	public void setReportFolderName(String reportFolderName) {
		this.reportFolderName = reportFolderName;
	}
	public String getNavigationFlag() {
		return navigationFlag;
	}
	public void setNavigationFlag(String navigationFlag) {
		this.navigationFlag = navigationFlag;
	}
	public String getIconLink() {
		return iconLink;
	}
	public void setIconLink(String iconLink) {
		this.iconLink = iconLink;
	}

}

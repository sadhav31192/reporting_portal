/**
 * @author Sandip Adhav
 */

/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Id;

/**
 * @author Sandip Adhav
 * Announcement Composite Key class
 *
 */
public class AnnouncementsId implements Serializable{
	
	
	private Date startDate;//3 dessending
	private Date endDate;
	private String announcementType;
	private String announcementText;
	public AnnouncementsId() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AnnouncementsId(Date startDate, Date endDate, String announcementType, String announcementText) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.announcementType = announcementType;
		this.announcementText = announcementText;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((announcementText == null) ? 0 : announcementText.hashCode());
		result = prime * result + ((announcementType == null) ? 0 : announcementType.hashCode());
		result = prime * result + ((endDate == null) ? 0 : endDate.hashCode());
		result = prime * result + ((startDate == null) ? 0 : startDate.hashCode());
		return result;
	}
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		AnnouncementsId other = (AnnouncementsId) obj;
		if (announcementText == null) {
			if (other.announcementText != null)
				return false;
		} else if (!announcementText.equals(other.announcementText))
			return false;
		if (announcementType == null) {
			if (other.announcementType != null)
				return false;
		} else if (!announcementType.equals(other.announcementType))
			return false;
		if (endDate == null) {
			if (other.endDate != null)
				return false;
		} else if (!endDate.equals(other.endDate))
			return false;
		if (startDate == null) {
			if (other.startDate != null)
				return false;
		} else if (!startDate.equals(other.startDate))
			return false;
		return true;
	}
		
}

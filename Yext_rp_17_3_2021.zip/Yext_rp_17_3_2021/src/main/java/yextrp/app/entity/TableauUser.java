/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

/**
 * @author Sandip Adhav
 *
 */
@Component
@Entity
@Table(name="TableauUser", schema = "reporting_portal")
public class TableauUser {
	@Id
	@Column
	String userId;
	@Column
	String name;
	@Column
	String groupId;
	@Column
	String groupName;
	@Column
	String authSetting;
	@Column
	String externalAuthUserId;
	@Column
	String lastLogin;
	@Column
	String siteRole;
	@Column
	String locale;
	@Column
	String language;
	
	public TableauUser(String userId, String name, String groupId, String groupName, String authSetting,
			String externalAuthUserId, String lastLogin, String siteRole, String locale, String language) {
		super();
		this.userId = userId;
		this.name = name;
		this.groupId = groupId;
		this.groupName = groupName;
		this.authSetting = authSetting;
		this.externalAuthUserId = externalAuthUserId;
		this.lastLogin = lastLogin;
		this.siteRole = siteRole;
		this.locale = locale;
		this.language = language;
	}
	
	
	public TableauUser() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	@Override
	public String toString() {
		return "TableauUser [userId=" + userId + ", name=" + name + ", groupId=" + groupId + ", groupName=" + groupName
				+ ", authSetting=" + authSetting + ", externalAuthUserId=" + externalAuthUserId + ", lastLogin="
				+ lastLogin + ", siteRole=" + siteRole + ", locale=" + locale + ", language=" + language + "]";
	}


	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getAuthSetting() {
		return authSetting;
	}
	public void setAuthSetting(String authSetting) {
		this.authSetting = authSetting;
	}
	public String getExternalAuthUserId() {
		return externalAuthUserId;
	}
	public void setExternalAuthUserId(String externalAuthUserId) {
		this.externalAuthUserId = externalAuthUserId;
	}
	public String getLastLogin() {
		return lastLogin;
	}
	public void setLastLogin(String lastLogin) {
		this.lastLogin = lastLogin;
	}
	public String getSiteRole() {
		return siteRole;
	}
	public void setSiteRole(String siteRole) {
		this.siteRole = siteRole;
	}
	public String getLocale() {
		return locale;
	}
	public void setLocale(String locale) {
		this.locale = locale;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}

	
	
}
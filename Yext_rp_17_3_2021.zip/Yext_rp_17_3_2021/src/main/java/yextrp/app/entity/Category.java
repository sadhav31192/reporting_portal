package yextrp.app.entity;

import java.util.List;

public class Category{
    public String categoryName;
    public List<String> reportFolders;
	public Category(String categoryName, List<String> reportFolders) {
		super();
		this.categoryName = categoryName;
		this.reportFolders = reportFolders;
	}
	public String getCategoryName() {
		return categoryName;
	}
	public void setCategoryName(String categoryName) {
		this.categoryName = categoryName;
	}
	public List<String> getReportFolders() {
		return reportFolders;
	}
	public void setReportFolders(List<String> reportFolders) {
		this.reportFolders = reportFolders;
	}
	public Category() {
		super();
		// TODO Auto-generated constructor stub
	}
    
    
}



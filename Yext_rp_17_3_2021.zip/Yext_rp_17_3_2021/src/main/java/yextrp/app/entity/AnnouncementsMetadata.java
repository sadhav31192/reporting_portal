/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;
import java.sql.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.lang.NonNull;
/**
 * @author Sandip Adhav
 *Entity class for AnnouncementsMetadata
 */
@Entity
@IdClass(AnnouncementsId.class)
@Table(name="AnnouncementsMetadata", schema = "reporting_portal")
public class AnnouncementsMetadata{
  
	@Id
	@Column
	@NotNull(message="start date must not be null")
	private Date startDate;//3 dessending
	@Id
	@Column
	@DateTimeFormat
	private Date endDate;
	@Id	
	@Column
	@NotBlank(message = "announcementType is mandatory")
	private String announcementType;
	@Id
	@Column
	private String announcementText;
	@NotBlank(message = "announcementTooltip is mandatory")
	private String announcementTooltip;
	@Column	
	@NotBlank(message = "urlForDetails is mandatory")
	private String urlForDetails;
	@Column
	private String displayOrder;//2 assending
	@Column
	private String showOnTop;//1
	@Column
	private Date insertDate;
	@Column 
	private String addedBy;
	@Column
	private Date lastModifiedDate;
	@Column
	private String lastModifiedBy;
	@Column
	private String softDeleteFlag;
	

	public AnnouncementsMetadata() {
		super();
		// TODO Auto-generated constructor stub
	}


	public AnnouncementsMetadata(@NotNull(message = "start date must not be null") Date startDate, Date endDate,
			@NotBlank(message = "announcementType is mandatory") String announcementType, String announcementText,
			@NotBlank(message = "announcementTooltip is mandatory") String announcementTooltip,
			@NotBlank(message = "urlForDetails is mandatory") String urlForDetails, String displayOrder,
			String showOnTop, Date insertDate, String addedBy, Date lastModifiedDate, String lastModifiedBy,
			String softDeleteFlag) {
		super();
		this.startDate = startDate;
		this.endDate = endDate;
		this.announcementType = announcementType;
		this.announcementText = announcementText;
		this.announcementTooltip = announcementTooltip;
		this.urlForDetails = urlForDetails;
		this.displayOrder = displayOrder;
		this.showOnTop = showOnTop;
		this.insertDate = insertDate;
		this.addedBy = addedBy;
		this.lastModifiedDate = lastModifiedDate;
		this.lastModifiedBy = lastModifiedBy;
		this.softDeleteFlag = softDeleteFlag;
	}


	@Override
	public String toString() {
		return "AnnouncementsMetadata [startDate=" + startDate + ", endDate=" + endDate + ", announcementType="
				+ announcementType + ", announcementText=" + announcementText + ", announcementTooltip="
				+ announcementTooltip + ", urlForDetails=" + urlForDetails + ", displayOrder=" + displayOrder
				+ ", showOnTop=" + showOnTop + ", insertDate=" + insertDate + ", addedBy=" + addedBy
				+ ", lastModifiedDate=" + lastModifiedDate + ", lastModifiedBy=" + lastModifiedBy + ", softDeleteFlag="
				+ softDeleteFlag + "]";
	}


	public Date getStartDate() {
		return startDate;
	}


	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}


	public Date getEndDate() {
		return endDate;
	}


	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}


	public String getAnnouncementType() {
		return announcementType;
	}


	public void setAnnouncementType(String announcementType) {
		this.announcementType = announcementType;
	}


	public String getAnnouncementText() {
		return announcementText;
	}


	public void setAnnouncementText(String announcementText) {
		this.announcementText = announcementText;
	}


	public String getAnnouncementTooltip() {
		return announcementTooltip;
	}


	public void setAnnouncementTooltip(String announcementTooltip) {
		this.announcementTooltip = announcementTooltip;
	}


	public String getUrlForDetails() {
		return urlForDetails;
	}


	public void setUrlForDetails(String urlForDetails) {
		this.urlForDetails = urlForDetails;
	}


	public String getDisplayOrder() {
		return displayOrder;
	}


	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}


	public String getShowOnTop() {
		return showOnTop;
	}


	public void setShowOnTop(String showOnTop) {
		this.showOnTop = showOnTop;
	}


	public Date getInsertDate() {
		return insertDate;
	}


	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}


	public String getAddedBy() {
		return addedBy;
	}


	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}


	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}


	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}


	public String getLastModifiedBy() {
		return lastModifiedBy;
	}


	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}


	public String getSoftDeleteFlag() {
		return softDeleteFlag;
	}


	public void setSoftDeleteFlag(String softDeleteFlag) {
		this.softDeleteFlag = softDeleteFlag;
	}

	

	





	

	
}

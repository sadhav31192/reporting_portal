/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.io.Serializable;

import javax.persistence.Column;

/**
 * @author Sandip Adhav
 *
 */
public class UserAccessId implements Serializable{
	private String userId;
	private String folderId;
	public UserAccessId(String userId, String folderId) {
		super();
		this.userId = userId;
		this.folderId = folderId;
	}
	public UserAccessId() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((folderId == null) ? 0 : folderId.hashCode());
		result = prime * result + ((userId == null) ? 0 : userId.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		UserAccessId other = (UserAccessId) obj;
		if (folderId == null) {
			if (other.folderId != null)
				return false;
		} else if (!folderId.equals(other.folderId))
			return false;
		if (userId == null) {
			if (other.userId != null)
				return false;
		} else if (!userId.equals(other.userId))
			return false;
		return true;
	}
	
	
}

package yextrp.app.entity;

import java.util.List;

public class SubFunction{
    public String subFunctionName;
    public List<Category> categories;
    public List<String> reportFolders;
	public SubFunction() {
		super();
		// TODO Auto-generated constructor stub
	}
	public SubFunction(String subFunctionName, List<Category> categories, List<String> reportFolders) {
		super();
		this.subFunctionName = subFunctionName;
		this.categories = categories;
		this.reportFolders = reportFolders;
	}
	public String getSubFunctionName() {
		return subFunctionName;
	}
	public void setSubFunctionName(String subFunctionName) {
		this.subFunctionName = subFunctionName;
	}
	public List<Category> getCategories() {
		return categories;
	}
	public void setCategories(List<Category> categories) {
		this.categories = categories;
	}
	public List<String> getReportFolders() {
		return reportFolders;
	}
	public void setReportFolders(List<String> reportFolders) {
		this.reportFolders = reportFolders;
	}
    
    
}
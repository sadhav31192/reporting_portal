/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import org.springframework.stereotype.Component;

/**
 * @author Sandip Adhav
 *
 */
@Component
public class AnnouncementsMetadataDTO {
	private String announcementId;
	private String AnnouncementType; 
	private String AnnouncementText; 
	private String AnnouncementTooltip; 
	private String UrlForDetails; 
	private String IconLink;
	public AnnouncementsMetadataDTO() {
		super();
		// TODO Auto-generated constructor stub
	}
	public AnnouncementsMetadataDTO(String announcementId, String announcementType, String announcementText,
			String announcementTooltip, String urlForDetails, String iconLink) {
		super();
		this.announcementId = announcementId;
		AnnouncementType = announcementType;
		AnnouncementText = announcementText;
		AnnouncementTooltip = announcementTooltip;
		UrlForDetails = urlForDetails;
		IconLink = iconLink;
	}
	@Override
	public String toString() {
		return "AnnouncementsMetadataDTO [announcementId=" + announcementId + ", AnnouncementType=" + AnnouncementType
				+ ", AnnouncementText=" + AnnouncementText + ", AnnouncementTooltip=" + AnnouncementTooltip
				+ ", UrlForDetails=" + UrlForDetails + ", IconLink=" + IconLink + "]";
	}
	public String getAnnouncementId() {
		return announcementId;
	}
	public void setAnnouncementId(String announcementId) {
		this.announcementId = announcementId;
	}
	public String getAnnouncementType() {
		return AnnouncementType;
	}
	public void setAnnouncementType(String announcementType) {
		AnnouncementType = announcementType;
	}
	public String getAnnouncementText() {
		return AnnouncementText;
	}
	public void setAnnouncementText(String announcementText) {
		AnnouncementText = announcementText;
	}
	public String getAnnouncementTooltip() {
		return AnnouncementTooltip;
	}
	public void setAnnouncementTooltip(String announcementTooltip) {
		AnnouncementTooltip = announcementTooltip;
	}
	public String getUrlForDetails() {
		return UrlForDetails;
	}
	public void setUrlForDetails(String urlForDetails) {
		UrlForDetails = urlForDetails;
	}
	public String getIconLink() {
		return IconLink;
	}
	public void setIconLink(String iconLink) {
		IconLink = iconLink;
	}
	
	
}

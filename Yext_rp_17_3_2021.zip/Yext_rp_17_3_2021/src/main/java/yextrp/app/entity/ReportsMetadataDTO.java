/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

/**
 * @author Sandip Adhav
 *
 */
public class ReportsMetadataDTO {
	private String reportsMetadataId;
	private String reportName;
	private String reportDescription;
	private String shortReportDescription;
	private String desktopUrl;
	private String businessOwnerName;
	private String businessOwnerEmail;
	private String topFunction;
	private String subFunction;
	private String category;
	private String reportFolderName;
	private String embeddedUrl;//
	private String editFlag;
	private String reportGlossaryUrl;
	private String soxComplianceFlag;
	private String boardReportingFlag;
	private String thumbnailIconUrl;// iconLink.path.reportThumbnails/reportname.png
	private String editIconUrl;// iconLink.path.editIcon
	private String embeddedIconUrl; // iconLink.path.embeddedLinkIcon
	private String businessUserIconUrl;// iconLink.path.businessUserIcon
	private String ticketMailIconUrl;// iconLink.path.ticketMailIcon
	private String soxFlagIconUrl;// iconLink.path.SOXFlagIcon
	private String boardReportingFlagIconUrl;// iconLink.path.boardReportingFlagFcon
	private String reportGlossaryIconUrl;// iconLink.path.metricDefinitionIcon

	public ReportsMetadataDTO() {
		super();
	}

	public ReportsMetadataDTO(String reportName, String reportDescription, String shortReportDescription,
			String desktopUrl, String businessOwnerName, String businessOwnerEmail, String topFunction,
			String subFunction, String category, String reportFolderName, String embeddedUrl, String editFlag,
			String reportGlossaryUrl, String soxComplianceFlag, String boardReportingFlag, String thumbnailIconUrl,
			String editIconUrl, String embeddedIconUrl, String businessUserIconUrl, String ticketMailIconUrl,
			String soxFlagIconUrl, String boardReportingFlagIconUrl, String reportGlossaryIconUrl) {
		super();
		this.reportName = reportName;
		this.reportDescription = reportDescription;
		this.shortReportDescription = shortReportDescription;
		this.desktopUrl = desktopUrl;
		this.businessOwnerName = businessOwnerName;
		this.businessOwnerEmail = businessOwnerEmail;
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.reportFolderName = reportFolderName;
		this.embeddedUrl = embeddedUrl;
		this.editFlag = editFlag;
		this.reportGlossaryUrl = reportGlossaryUrl;
		this.soxComplianceFlag = soxComplianceFlag;
		this.boardReportingFlag = boardReportingFlag;
		this.thumbnailIconUrl = thumbnailIconUrl;
		this.editIconUrl = editIconUrl;
		this.embeddedIconUrl = embeddedIconUrl;
		this.businessUserIconUrl = businessUserIconUrl;
		this.ticketMailIconUrl = ticketMailIconUrl;
		this.soxFlagIconUrl = soxFlagIconUrl;
		this.boardReportingFlagIconUrl = boardReportingFlagIconUrl;
		this.reportGlossaryIconUrl = reportGlossaryIconUrl;
	}

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public String getReportDescription() {
		return reportDescription;
	}

	public void setReportDescription(String reportDescription) {
		this.reportDescription = reportDescription;
	}

	public String getShortReportDescription() {
		return shortReportDescription;
	}

	public void setShortReportDescription(String shortReportDescription) {
		this.shortReportDescription = shortReportDescription;
	}

	public String getDesktopUrl() {
		return desktopUrl;
	}

	public void setDesktopUrl(String desktopUrl) {
		this.desktopUrl = desktopUrl;
	}

	public String getBusinessOwnerName() {
		return businessOwnerName;
	}

	public void setBusinessOwnerName(String businessOwnerName) {
		this.businessOwnerName = businessOwnerName;
	}

	public String getBusinessOwnerEmail() {
		return businessOwnerEmail;
	}

	public void setBusinessOwnerEmail(String businessOwnerEmail) {
		this.businessOwnerEmail = businessOwnerEmail;
	}

	public String getTopFunction() {
		return topFunction;
	}

	public void setTopFunction(String topFunction) {
		this.topFunction = topFunction;
	}

	public String getSubFunction() {
		return subFunction;
	}

	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getReportFolderName() {
		return reportFolderName;
	}

	public void setReportFolderName(String reportFolderName) {
		this.reportFolderName = reportFolderName;
	}

	public String getEmbeddedUrl() {
		return embeddedUrl;
	}

	public void setEmbeddedUrl(String embeddedUrl) {
		this.embeddedUrl = embeddedUrl;
	}

	public String getEditFlag() {
		return editFlag;
	}

	public void setEditFlag(String editFlag) {
		this.editFlag = editFlag;
	}

	public String getReportGlossaryUrl() {
		return reportGlossaryUrl;
	}

	public void setReportGlossaryUrl(String reportGlossaryUrl) {
		this.reportGlossaryUrl = reportGlossaryUrl;
	}

	public String getSoxComplianceFlag() {
		return soxComplianceFlag;
	}

	public void setSoxComplianceFlag(String soxComplianceFlag) {
		this.soxComplianceFlag = soxComplianceFlag;
	}

	public String getBoardReportingFlag() {
		return boardReportingFlag;
	}

	public void setBoardReportingFlag(String boardReportingFlag) {
		this.boardReportingFlag = boardReportingFlag;
	}

	public String getThumbnailIconUrl() {
		return thumbnailIconUrl;
	}

	public void setThumbnailIconUrl(String thumbnailIconUrl) {
		this.thumbnailIconUrl = thumbnailIconUrl;
	}

	public String getEditIconUrl() {
		return editIconUrl;
	}

	public void setEditIconUrl(String editIconUrl) {
		this.editIconUrl = editIconUrl;
	}

	public String getEmbeddedIconUrl() {
		return embeddedIconUrl;
	}

	public void setEmbeddedIconUrl(String embeddedIconUrl) {
		this.embeddedIconUrl = embeddedIconUrl;
	}

	public String getBusinessUserIconUrl() {
		return businessUserIconUrl;
	}

	public void setBusinessUserIconUrl(String businessUserIconUrl) {
		this.businessUserIconUrl = businessUserIconUrl;
	}

	public String getTicketMailIconUrl() {
		return ticketMailIconUrl;
	}

	public void setTicketMailIconUrl(String ticketMailIconUrl) {
		this.ticketMailIconUrl = ticketMailIconUrl;
	}

	public String getSoxFlagIconUrl() {
		return soxFlagIconUrl;
	}

	public void setSoxFlagIconUrl(String soxFlagIconUrl) {
		this.soxFlagIconUrl = soxFlagIconUrl;
	}

	public String getBoardReportingFlagIconUrl() {
		return boardReportingFlagIconUrl;
	}

	public void setBoardReportingFlagIconUrl(String boardReportingFlagIconUrl) {
		this.boardReportingFlagIconUrl = boardReportingFlagIconUrl;
	}

	public String getReportGlossaryIconUrl() {
		return reportGlossaryIconUrl;
	}

	public void setReportGlossaryIconUrl(String reportGlossaryIconUrl) {
		this.reportGlossaryIconUrl = reportGlossaryIconUrl;
	}

	@Override
	public String toString() {
		return "ReportsMetadataDTO [reportName=" + reportName + ", reportDescription=" + reportDescription
				+ ", shortReportDescription=" + shortReportDescription + ", desktopUrl=" + desktopUrl
				+ ", businessOwnerName=" + businessOwnerName + ", businessOwnerEmail=" + businessOwnerEmail
				+ ", topFunction=" + topFunction + ", subFunction=" + subFunction + ", category=" + category
				+ ", reportFolderName=" + reportFolderName + ", embeddedUrl=" + embeddedUrl + ", editFlag=" + editFlag
				+ ", reportGlossaryUrl=" + reportGlossaryUrl + ", soxComplianceFlag=" + soxComplianceFlag
				+ ", boardReportingFlag=" + boardReportingFlag + ", thumbnailIconUrl=" + thumbnailIconUrl
				+ ", editIconUrl=" + editIconUrl + ", embeddedIconUrl=" + embeddedIconUrl + ", businessUserIconUrl="
				+ businessUserIconUrl + ", ticketMailIconUrl=" + ticketMailIconUrl + ", soxFlagIconUrl="
				+ soxFlagIconUrl + ", boardReportingFlagIconUrl=" + boardReportingFlagIconUrl
				+ ", reportGlossaryIconUrl=" + reportGlossaryIconUrl + "]";
	}

}

package yextrp.app.entity;

import java.io.Serializable;
import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
/**
 * Entity class for TrainingsMetadata
 * @author Sandip Adhav
 *
 */
@Entity
@IdClass(TrainingsId.class)
@Table(name="TrainingsMetadata", schema = "reporting_portal")
public class TrainingsMetadata implements Serializable {
	
	@Id
	@Column
	@NotNull(message="training date must not be null")
	private Date addedDate;
	@Id
	@Column
	@NotBlank(message = "contentType is mandatory")
	private String contentType;
	@Id
	@Column
	@NotBlank(message = "trainingSummary is mandatory")
	private String trainingSummary;
	@Column
	private String trainingDetailsTooltip;
	@Column
	@NotBlank(message = "trainingUrl is mandatory")
	private String trainingUrl;
	@Column
	private String displayOrder;
	@Column
	private String showOnTop;
	@Column
	private Date insertDate;
	@Column 
	private String addedBy;
	@Column
	private Date lastModifiedDate;
	@Column
	private String lastModifiedBy;
	@Column
	private String softDeleteFlag;
	
	
	public TrainingsMetadata() {
		super();
		// TODO Auto-generated constructor stub
	}


	public TrainingsMetadata(@NotNull(message = "training date must not be null") Date addedDate,
			@NotBlank(message = "contentType is mandatory") String contentType,
			@NotBlank(message = "trainingSummary is mandatory") String trainingSummary, String trainingDetailsTooltip,
			@NotBlank(message = "trainingUrl is mandatory") String trainingUrl, String displayOrder, String showOnTop,
			Date insertDate, String addedBy, Date lastModifiedDate, String lastModifiedBy, String softDeleteFlag) {
		super();
		this.addedDate = addedDate;
		this.contentType = contentType;
		this.trainingSummary = trainingSummary;
		this.trainingDetailsTooltip = trainingDetailsTooltip;
		this.trainingUrl = trainingUrl;
		this.displayOrder = displayOrder;
		this.showOnTop = showOnTop;
		this.insertDate = insertDate;
		this.addedBy = addedBy;
		this.lastModifiedDate = lastModifiedDate;
		this.lastModifiedBy = lastModifiedBy;
		this.softDeleteFlag = softDeleteFlag;
	}


	@Override
	public String toString() {
		return "TrainingsMetadata [addedDate=" + addedDate + ", contentType=" + contentType + ", trainingSummary="
				+ trainingSummary + ", trainingDetailsTooltip=" + trainingDetailsTooltip + ", trainingUrl="
				+ trainingUrl + ", displayOrder=" + displayOrder + ", showOnTop=" + showOnTop + ", insertDate="
				+ insertDate + ", addedBy=" + addedBy + ", lastModifiedDate=" + lastModifiedDate + ", lastModifiedBy="
				+ lastModifiedBy + ", softDeleteFlag=" + softDeleteFlag + "]";
	}


	public Date getAddedDate() {
		return addedDate;
	}


	public void setAddedDate(Date addedDate) {
		this.addedDate = addedDate;
	}


	public String getContentType() {
		return contentType;
	}


	public void setContentType(String contentType) {
		this.contentType = contentType;
	}


	public String getTrainingSummary() {
		return trainingSummary;
	}


	public void setTrainingSummary(String trainingSummary) {
		this.trainingSummary = trainingSummary;
	}


	public String getTrainingDetailsTooltip() {
		return trainingDetailsTooltip;
	}


	public void setTrainingDetailsTooltip(String trainingDetailsTooltip) {
		this.trainingDetailsTooltip = trainingDetailsTooltip;
	}


	public String getTrainingUrl() {
		return trainingUrl;
	}


	public void setTrainingUrl(String trainingUrl) {
		this.trainingUrl = trainingUrl;
	}


	public String getDisplayOrder() {
		return displayOrder;
	}


	public void setDisplayOrder(String displayOrder) {
		this.displayOrder = displayOrder;
	}


	public String getShowOnTop() {
		return showOnTop;
	}


	public void setShowOnTop(String showOnTop) {
		this.showOnTop = showOnTop;
	}


	public Date getInsertDate() {
		return insertDate;
	}


	public void setInsertDate(Date insertDate) {
		this.insertDate = insertDate;
	}


	public String getAddedBy() {
		return addedBy;
	}


	public void setAddedBy(String addedBy) {
		this.addedBy = addedBy;
	}


	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}


	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}


	public String getLastModifiedBy() {
		return lastModifiedBy;
	}


	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}


	public String getSoftDeleteFlag() {
		return softDeleteFlag;
	}


	public void setSoftDeleteFlag(String softDeleteFlag) {
		this.softDeleteFlag = softDeleteFlag;
	}
	
	
}

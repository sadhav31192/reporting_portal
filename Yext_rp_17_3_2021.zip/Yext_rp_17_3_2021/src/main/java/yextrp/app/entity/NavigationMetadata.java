/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * @author Sandip Adhav
 *
 */
@Entity
@IdClass(NavigationMetdataId.class)
@Table(name="NavigationMetadata", schema = "reporting_portal")
public class NavigationMetadata implements Serializable{
	
	@Id
	@Column
	private String topFunction;
	@Id
	@Column
	private String subFunction;
	@Id
	@Column
	private String category;
	@Id
	@Column
	private String source;
	@Column	
	private String  folderUrl;
    @Column	
	private String  folderId;
	public NavigationMetadata() {
		super();
		// TODO Auto-generated constructor stub
	}
	public NavigationMetadata(String topFunction, String subFunction, String category, String source, String folderUrl,
			String folderId) {
		super();
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.source = source;
		this.folderUrl = folderUrl;
		this.folderId = folderId;
	}
	@Override
	public String toString() {
		return "NavigationMetadata [topFunction=" + topFunction + ", subFunction=" + subFunction + ", category="
				+ category + ", source=" + source + ", folderUrl=" + folderUrl + ", folderId=" + folderId + "]";
	}
	public String getTopFunction() {
		return topFunction;
	}
	public void setTopFunction(String topFunction) {
		this.topFunction = topFunction;
	}
	public String getSubFunction() {
		return subFunction;
	}
	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getFolderUrl() {
		return folderUrl;
	}
	public void setFolderUrl(String folderUrl) {
		this.folderUrl = folderUrl;
	}
	public String getFolderId() {
		return folderId;
	}
	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}
	
    
}

/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Table;

/**
 * @author Sandip Adhav
 *
 */

@Entity
@IdClass(UserAccessId.class)
@Table(name="UserAccess", schema = "reporting_portal")
public class UserAccess {
	@Column
	private String topFunction;
	@Column
	private String subFunction;
	@Column
	private String category;
	@Id
	@Column
	private String userId;
	@Column
	private String userName;
	@Id
	@Column
	private String folderId;
	public UserAccess(String topFunction, String subFunction, String category, String userId, String userName,
			String folderId) {
		super();
		this.topFunction = topFunction;
		this.subFunction = subFunction;
		this.category = category;
		this.userId = userId;
		this.userName = userName;
		this.folderId = folderId;
	}
	public String getTopFunction() {
		return topFunction;
	}
	public void setTopFunction(String topFunction) {
		this.topFunction = topFunction;
	}
	public String getSubFunction() {
		return subFunction;
	}
	public void setSubFunction(String subFunction) {
		this.subFunction = subFunction;
	}
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFolderId() {
		return folderId;
	}
	public void setFolderId(String folderId) {
		this.folderId = folderId;
	}
	public UserAccess() {
		super();
		// TODO Auto-generated constructor stub
	}

}

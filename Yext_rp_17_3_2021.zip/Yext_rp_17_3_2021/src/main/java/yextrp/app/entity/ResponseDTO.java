/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import java.io.Serializable;
import java.util.List;

/**
 * @author Sandip Adhav
 *
 */
public class ResponseDTO implements Serializable{
	
	private int status;
	private String message;
	private Object data;
	private List<String> details;
	
	public ResponseDTO(int status, String message, Object data, List<String> details) {
		super();
		this.status = status;
		this.message = message;
		this.data = data;
		this.details = details;
	}
	
	
	public ResponseDTO(int status, String message, List<String> details) {
		super();
		this.status = status;
		this.message = message;
		this.details = details;
	}
	
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Object getData() {
		return data;
	}
	public void setData(Object data) {
		this.data = data;
	}
	public List<String> getDetails() {
		return details;
	}
	public void setDetails(List<String> details) {
		this.details = details;
	}
	@Override
	public String toString() {
		return "ResponseDTO [status=" + status + ", message=" + message + ", data=" + data + ", details=" + details
				+ "]";
	}
	
	
}


/*
 * public ResponseDTO(String message, List<String> details) { super();
 * this.message = message; this.details = details; }
 * 
 * public ResponseDTO() { super(); // TODO Auto-generated constructor stub }
 * 
 * //General error message about nature of error private String message;
 * 
 * //Specific errors in API request processing private List<String> details;
 * 
 * public String getMessage() { return message; }
 * 
 * public void setMessage(String message) { this.message = message; }
 * 
 * public List<String> getDetails() { return details; }
 * 
 * public void setDetails(List<String> details) { this.details = details; }
 */

/**
 * @author Sandip Adhav
 */
package yextrp.app.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

/**
 * @author Sandip Adhav
 *
 */
@Component
@Entity
@Table(name="TableauWorkbook", schema = "reporting_portal")
public class TableauWorkbook {
	@Id
	@Column
	private String workbookId;
	@Column
	private String workbookName;
	@Column
	private String projectId;
	@Column
	private String projectName;
	@Column
	private String ownerId;
	@Column
	private String ownerName;
	@Column
	private String description;
	@Column
	private String contentUrl ;
	@Column
	private String webpageUrl;
	@Column
	private String showTabs;
	@Column
	private String size;
	@Column
	private String createdAt;
	@Column
	private String updatedAt;
	@Column
	private String encryptExtracts;
	@Column
	private String defaultViewId;
	public TableauWorkbook(String projectId, String projectName, String ownerId, String ownerName, String workbookId,
			String workbookName, String description, String contentUrl, String webpageUrl, String showTabs, String size,
			String createdAt, String updatedAt, String encryptExtracts, String defaultViewId) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.ownerId = ownerId;
		this.ownerName = ownerName;
		this.workbookId = workbookId;
		this.workbookName = workbookName;
		this.description = description;
		this.contentUrl = contentUrl;
		this.webpageUrl = webpageUrl;
		this.showTabs = showTabs;
		this.size = size;
		this.createdAt = createdAt;
		this.updatedAt = updatedAt;
		this.encryptExtracts = encryptExtracts;
		this.defaultViewId = defaultViewId;
	}
	public TableauWorkbook() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "TableauWorkbook [projectId=" + projectId + ", projectName=" + projectName + ", ownerId=" + ownerId
				+ ", ownerName=" + ownerName + ", workbookId=" + workbookId + ", workbookName=" + workbookName
				+ ", description=" + description + ", contentUrl=" + contentUrl + ", webpageUrl=" + webpageUrl
				+ ", showTabs=" + showTabs + ", size=" + size + ", createdAt=" + createdAt + ", updatedAt=" + updatedAt
				+ ", encryptExtracts=" + encryptExtracts + ", defaultViewId=" + defaultViewId + "]";
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getOwnerId() {
		return ownerId;
	}
	public void setOwnerId(String ownerId) {
		this.ownerId = ownerId;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getWorkbookId() {
		return workbookId;
	}
	public void setWorkbookId(String workbookId) {
		this.workbookId = workbookId;
	}
	public String getWorkbookName() {
		return workbookName;
	}
	public void setWorkbookName(String workbookName) {
		this.workbookName = workbookName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getContentUrl() {
		return contentUrl;
	}
	public void setContentUrl(String contentUrl) {
		this.contentUrl = contentUrl;
	}
	public String getWebpageUrl() {
		return webpageUrl;
	}
	public void setWebpageUrl(String webpageUrl) {
		this.webpageUrl = webpageUrl;
	}
	public String getShowTabs() {
		return showTabs;
	}
	public void setShowTabs(String showTabs) {
		this.showTabs = showTabs;
	}
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	public String getCreatedAt() {
		return createdAt;
	}
	public void setCreatedAt(String createdAt) {
		this.createdAt = createdAt;
	}
	public String getUpdatedAt() {
		return updatedAt;
	}
	public void setUpdatedAt(String updatedAt) {
		this.updatedAt = updatedAt;
	}
	public String getEncryptExtracts() {
		return encryptExtracts;
	}
	public void setEncryptExtracts(String encryptExtracts) {
		this.encryptExtracts = encryptExtracts;
	}
	public String getDefaultViewId() {
		return defaultViewId;
	}
	public void setDefaultViewId(String defaultViewId) {
		this.defaultViewId = defaultViewId;
	}
	
	
}

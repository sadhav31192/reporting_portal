
package yextrp.app.Services;
import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import yextrp.app.Repository.TableauUserRepository;
import yextrp.app.Repository.UserAccessRepository;
import yextrp.app.model.UserDetails;
/**
 * @author Vaibhav Aware
 *Tableau Users Related Services like get logged in user, get logged in users group
 */
@Service
public class UserServices {
	@Autowired
	TableauUserRepository tableauUserRepository; 
	@Autowired
	UserAccessRepository userAccessRepository;
	
	 public String getLoggedInUser(){
		 return "Shraddha Nigade"; 
	 }
	
	/* public String getLoggedInUser() { 
		  Authentication auth = SecurityContextHolder.getContext().getAuthentication();
		  SAMLCredential credentials = (SAMLCredential) auth.getCredentials(); 
		  String username=credentials.getNameID().getValue(); return username;
		  }
	  */
	
	/*
	  public String getLoggedinUserGroup() { String username=getLoggedInUser();
	  System.out.println(username); return
	  tableauUserRepository.findUserGroupByUsername(username); }
	 */
	
	public ArrayList<String> getUserAccess(String userId) {
		return userAccessRepository.findUserAccess(userId);
	}
	
	public String getUserIdByUsername(String name) {
		
		return "snigade";
	}
	
	public UserDetails getLoggedInUserFolders() {
		
		//return userAccessRepository.userAccessRepository(getLoggedInUser());
		
		String user="snigade";
		
		return new UserDetails(user,userAccessRepository.getLoggedInUser(user));
	}
	
}
/**
 * @author Sandip Adhav
 */
package yextrp.app.controller;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * @author Sandip Adhav
 *
 */
@CrossOrigin(origins = "*", allowedHeaders = "*") 
@RequestMapping("/configuration")
@RestController
public class ConfigurationController {
	 @Value("${api.getAnnouncements}") String getAnnouncementsApi;
	 
	  @Value("${api.getTrainings}") String getTrainingsApi;
	  
	  @Value("${api.getReports}") String getReportsApi;
	  
	  @Value("${api.getNavigation}") String getNavigationApi;
	 
	  @Value("${app.baseUrl}") String getBaseUrl;
	  
	  @Value("${api.getUser}") String getUserApi;
	
	@GetMapping(path="/getConfiguration", produces = "application/json")	
	public Object getAnnouncements(){
	return null;
	}
}
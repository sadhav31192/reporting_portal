package yextrp.app.controller;

import java.util.ArrayList;
import java.util.Collection;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import yextrp.app.Repository.NavigationMetadataRepository;
import yextrp.app.Repository.ReportsMetadataRepository;
import yextrp.app.Services.UserServices;
import yextrp.app.entity.ReportsMetadata;
import yextrp.app.entity.ReportsMetadataDTO;
import yextrp.app.exceptionHandler.CustomExceptions;
import yextrp.app.exceptionHandler.CustomExceptions.DataNotFoundException;

/**
 * @author Sandip Adhav
 * Reports Metadata APIs
 */
@CrossOrigin(origins = "*", allowedHeaders = "*") 
@RequestMapping("/reports")
@RestController
public class ReportsController {
	@Autowired
	ReportsMetadataRepository reportsMetadataRepository;
	@Autowired
	NavigationMetadataRepository navigationMetadataRepository;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	UserServices userServices;
	@Value("${iconLink.path.reportThumbnails}") String thumbnailIconUrl; 
	@Value("${iconLink.path.editIcon}") String editIconUrl;
	@Value("${iconLink.path.embeddedLinkIcon}") String embeddedIconUrl;
	@Value("${iconLink.path.businessUserIcon}") String businessUserIconUrl;
	@Value("${iconLink.path.ticketMailIcon}") String ticketMailIconUrl;
	@Value("${iconLink.path.SOXFlagIcon}") String soxFlagIconUrl;
	@Value("${iconLink.path.boardReportingFlagFcon}") String boardReportingFlagIconUrl;
	@Value("${iconLink.path.metricDefinitionIcon}") String reportGlossaryIconUrl;
	/**
	 * API to access the reports according to users roles and groups
	 * @return all the reports metadata according to Navigation data/folderID
	 * @throws Exception 
	 */	
	@GetMapping(path="/getReports", produces = "application/json")
	public ResponseEntity<Object> getReports() throws Exception{
		String username=userServices.getLoggedInUser();
		String userId = userServices.getUserIdByUsername(username);
		ArrayList<String> listOfReportFolderId =userServices.getUserAccess(userId);
		Collection<ReportsMetadata> listOfReportsMetadata=reportsMetadataRepository.findReportsByfolderId(listOfReportFolderId);
		ArrayList<ReportsMetadataDTO> listOfReportsMetadataDTO=new ArrayList<ReportsMetadataDTO>(); 
		if(listOfReportsMetadata.isEmpty() || listOfReportsMetadata == null || listOfReportsMetadata.size()==0){
			throw new CustomExceptions.DataNotFoundException("Reports Data is Empty");
		}
		for (ReportsMetadata reportsMetadata : listOfReportsMetadata){
			ReportsMetadataDTO reportsMetadataDTO=modelMapper.map(reportsMetadata, ReportsMetadataDTO.class);
			String shortDescription=reportsMetadata.getReportDescription();
			if(shortDescription!=null&&!shortDescription.equals("")&&shortDescription.length()>=110) {
				shortDescription=shortDescription.substring(0,80)+"...";
				reportsMetadataDTO.setShortReportDescription(shortDescription);
			}
			else
				reportsMetadataDTO.setShortReportDescription(shortDescription);
			if(reportsMetadataDTO.getBusinessOwnerName().equals(userServices.getLoggedInUser())) {
				reportsMetadataDTO.setEditFlag("true");
			}
			reportsMetadataDTO.setThumbnailIconUrl(thumbnailIconUrl+reportsMetadataDTO.getReportName().replaceAll(" ","").replaceAll("\\[","(").replaceAll("\\]",")")+".png");
			reportsMetadataDTO.setEditIconUrl(editIconUrl);
			reportsMetadataDTO.setEmbeddedIconUrl(embeddedIconUrl);
			reportsMetadataDTO.setBusinessUserIconUrl(businessUserIconUrl);
			reportsMetadataDTO.setTicketMailIconUrl(ticketMailIconUrl);
			reportsMetadataDTO.setSoxFlagIconUrl(soxFlagIconUrl);
			reportsMetadataDTO.setBoardReportingFlagIconUrl(boardReportingFlagIconUrl);
			reportsMetadataDTO.setReportGlossaryIconUrl(reportGlossaryIconUrl);
			listOfReportsMetadataDTO.add(reportsMetadataDTO);
		}
		return new ResponseEntity<Object>(listOfReportsMetadataDTO,HttpStatus.OK); 
	} 
}

/**
 * @author Sandip Adhav
 */
package yextrp.app.controller;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import yextrp.app.Repository.NavigationMetadataRepository;
import yextrp.app.Services.UserServices;
import yextrp.app.entity.Category;
import yextrp.app.entity.NavigationDto;
import yextrp.app.entity.NavigationMetadata;
import yextrp.app.entity.SubFunction;
import yextrp.app.exceptionHandler.CustomExceptions;

/**
 * @author Sandip Adhav
 *Navigation Controller  
 */
@CrossOrigin(origins = "*", allowedHeaders = "*") 
@RequestMapping("/navigation")
@RestController
public class NavigationController {
	@Autowired
	NavigationMetadataRepository navigationMetadataRepository;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	UserServices userServices;
	@Autowired
	private Environment env;
	/**
	 * @param reportCategory
	 * @return
	 */
	@PostMapping("/addNavigation")
	public Boolean addNavigation(@RequestBody NavigationMetadata navigationMetadata) {
		navigationMetadataRepository.save(navigationMetadata);
		return true;
	}
	/**
	 * returning list of navigation data according to user group/folderids
	 * @return List of Navigation Data
	 * @throws Exception
	 */
	
	@GetMapping("/getNavigation")
	public ResponseEntity<Object>  getNavigation() throws Exception {
		//user access code
		String userId = "snigade";
		ArrayList<String> listofFolderIds =userServices.getUserAccess(userId);
	    String url=env.getProperty("iconLink.path.navigation");
		ArrayList<NavigationMetadata> listOfNavigationMetadata = (ArrayList<NavigationMetadata>) navigationMetadataRepository
				.findNavigationMetadata(listofFolderIds);
		if(listOfNavigationMetadata.isEmpty() || listOfNavigationMetadata == null || listOfNavigationMetadata.size()==0){
			throw new CustomExceptions.DataNotFoundException("Navigation Data is Empty");
		}
		
		HashSet<String> topFunctions = new HashSet<>();
		listOfNavigationMetadata.stream().forEach(row -> {
			topFunctions.add(row.getTopFunction());
		});

		List<NavigationDto> navigationDtoList = new ArrayList<>();

		for (String topFunction : topFunctions) {

			NavigationDto nvd = new NavigationDto();
			nvd.setTopFunctionName(topFunction);

			HashSet<String> subFunctions = getSubFunctionList(topFunction, listOfNavigationMetadata);
			List<SubFunction> subFunctionsList = new ArrayList<>();

			for (String subFunction : subFunctions) {

				SubFunction subFunctionObject = new SubFunction();
				subFunctionObject.setSubFunctionName(subFunction);
				HashSet<String> categories = getCategoriesList(subFunction, listOfNavigationMetadata);
				List<Category> categoriesList = new ArrayList<>();

				for (String category : categories) {
					if (category.equalsIgnoreCase("N/A"))
						continue;
					Category categoryObject = new Category();
					categoryObject.setCategoryName(category);
					HashSet<String> reportFolders = getReportFoldersList(category, listOfNavigationMetadata);
					categoryObject.setReportFolders(new ArrayList<String>(reportFolders));
					categoriesList.add(categoryObject);
				}
				HashSet<String> reportFolders = null;
				if (categoriesList != null && categoriesList.size() > 0)
					subFunctionObject.setCategories(categoriesList);

				else {
					reportFolders = getReportFoldersForSubList(subFunction, listOfNavigationMetadata);
					subFunctionObject.setReportFolders(new ArrayList<String>(reportFolders));
				}

				subFunctionsList.add(subFunctionObject);
			} // end of subfunction
			nvd.setSubFunctions(subFunctionsList);
			nvd.setIconLink(url + topFunction.toLowerCase().replaceAll("\\s+", "") + ".png");
			navigationDtoList.add(nvd);
		}
		//Sorted by name of Top Function
	//	navigationDtoList=navigationDtoList.stream().sorted(Comparator.comparing(NavigationDto::getTopFunctionName)).collect(Collectors.toList());
		return new ResponseEntity<Object>(navigationDtoList,HttpStatus.OK);
	}

	private HashSet<String> getReportFoldersForSubList(String subfunction,
			ArrayList<NavigationMetadata> listOfNavigationMetadata) {

		HashSet<String> reportFolders = new HashSet<>();

		listOfNavigationMetadata.stream().filter(row -> row.getSubFunction().equalsIgnoreCase(subfunction))
				.forEach(row -> {
					reportFolders.add(row.getSource());
				});

		return reportFolders;
	}

	private HashSet<String> getReportFoldersList(String category,
			ArrayList<NavigationMetadata> listOfNavigationMetadata) {

		HashSet<String> reportFolders = new HashSet<>();

		listOfNavigationMetadata.stream().filter(row -> row.getCategory().equalsIgnoreCase(category)).forEach(row -> {
			reportFolders.add(row.getSource());
		});

		return reportFolders;
	}

	private HashSet<String> getCategoriesList(String subFunctionObject,
			ArrayList<NavigationMetadata> listOfNavigationMetadata) {
		HashSet<String> categories = new HashSet<>();

		listOfNavigationMetadata.stream().filter(row -> row.getSubFunction().equalsIgnoreCase(subFunctionObject))
				.forEach(row -> {
					categories.add(row.getCategory());
				});

		return categories;
	}

	private HashSet<String> getSubFunctionList(String topFunction,
			ArrayList<NavigationMetadata> listOfNavigationMetadata) {

		HashSet<String> subFunctions = new HashSet<>();

		listOfNavigationMetadata.stream().filter(row -> row.getTopFunction().equalsIgnoreCase(topFunction))
				.forEach(row -> {
					subFunctions.add(row.getSubFunction());
				});

		return subFunctions;
		
	
	}
	
}

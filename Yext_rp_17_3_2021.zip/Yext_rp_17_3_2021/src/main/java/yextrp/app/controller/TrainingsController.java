package yextrp.app.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import yextrp.app.Repository.TrainingsMetadataRepository;
import yextrp.app.entity.ResponseDTO;
import yextrp.app.entity.TrainingsMetadata;
import yextrp.app.entity.TrainingsMetadataDTO;
import yextrp.app.exceptionHandler.CustomExceptions;
import yextrp.app.exceptionHandler.CustomExceptions.DataNotFoundException;


/**
 * @author Sandip Adhav
 * Trainings Metadata Rest APIs
 */
@CrossOrigin(origins = "*", allowedHeaders = "*") 
@RequestMapping("/trainings")
@RestController
public class TrainingsController {
	@Autowired
	TrainingsMetadataRepository trainingsMetadataRepository;
	@Autowired
	ModelMapper modelMapper;
	@Autowired
	private Environment env;
	
	/**
	 * API to add Trainings Metadata
	 * @param trainingsMetadata
	 * @return boolean value
	 */
	@RequestMapping("/addTraining")
	@PostMapping
	public ResponseEntity<Object> saveReport(@RequestBody TrainingsMetadata trainingsMetadata) {
		try {
		trainingsMetadataRepository.save(trainingsMetadata);
		return new ResponseEntity<Object>(trainingsMetadata, HttpStatus.OK);
		}
		catch(Exception ex) {
			List<String> details = new ArrayList<>();
			details.add(ex.getLocalizedMessage());
			ResponseDTO dto=new ResponseDTO(HttpStatus.INTERNAL_SERVER_ERROR.value(),"Validation Failed",details);
			return new ResponseEntity( dto,HttpStatus.INTERNAL_SERVER_ERROR);
		}
	} 
	/**
	 * API to access the Trainings Meatadata
	 * @return all the Trainings metadata 
	 * @throws DataNotFoundException 
	 */		
	@GetMapping("/getTrainings")
	public Collection<TrainingsMetadataDTO> getTrainings() throws DataNotFoundException {
		String url=env.getProperty("iconLink.path.trainings");
		ArrayList<TrainingsMetadata> listOfTrainings=(ArrayList<TrainingsMetadata>) trainingsMetadataRepository.findTrainingsByRank();   	
		ArrayList<TrainingsMetadataDTO> listofTrainingsMetadataDTOs=new ArrayList<TrainingsMetadataDTO>();
		if(listOfTrainings.isEmpty()){
			throw new CustomExceptions.DataNotFoundException("Trainings Data is Empty");
		}
		for (TrainingsMetadata trainingsMetadata : listOfTrainings) {
		  		TrainingsMetadataDTO trainingsMetadataDTO  = modelMapper.map(trainingsMetadata, TrainingsMetadataDTO.class);  
		  		String a=trainingsMetadataDTO.getContentType();
		  		trainingsMetadataDTO.setIconLink(url+a.toLowerCase().replaceAll(" ","")+".png");
		  		listofTrainingsMetadataDTOs.add(trainingsMetadataDTO);	
			}
		  return listofTrainingsMetadataDTOs;
				  
	} 
		
		
	
	
}

/**
 * @author Sandip Adhav
 */
package yextrp.app.controller;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;

import yextrp.app.Services.TableauServices;
import yextrp.app.Services.UserServices;

/**
 * @author Sandip Adhav
 *
 */
@RequestMapping("/tableauServices")
@RestController
public class TableauServicesController {
	@Autowired
	RestTemplate restTemplate;
	@Autowired
	TableauServices tableauServices;
	@Autowired
	UserServices userServices;
	
	@GetMapping("/saveUserGroupMapping")
	public void  getAllUserGroupMapping() throws JsonMappingException, JsonProcessingException{
		HashMap<Object,Object> credentials=tableauServices.connectToTableau();		  				  
		String token=(String) credentials.get("token");
		System.out.println(token);
		String tableauUsersDataUrl = "https://prod-useast-a.online.tableau.com/api/3.9/sites/422cd704-a0a0-423e-b863-864a294e51d6/groups/e681d6b4-a2c9-4607-8af7-9cd65300580f/users?pageNumber=";
		tableauServices.SaveAllUsersData(token,tableauUsersDataUrl); 
		String tableauUserGroupsDataUrl = "https://prod-useast-a.online.tableau.com/api/3.9/sites/422cd704-a0a0-423e-b863-864a294e51d6/groups?pageNumber=";
	    tableauServices.saveUserGroupData(token,tableauUserGroupsDataUrl);
	   
	}
	
	@GetMapping("saveProjects")
	public void saveProject() throws JsonMappingException, JsonProcessingException 
	{
		System.out.println("inside");
		HashMap<Object,Object> credentials=tableauServices.connectToTableau();		  				  
		String token=(String) credentials.get("token");
		System.out.println(token);
		String tableauProjectsDataUrl="https://prod-useast-a.online.tableau.com/api/3.9/sites/422cd704-a0a0-423e-b863-864a294e51d6/projects?pageNumber=";   
		tableauServices.saveProjects(token,tableauProjectsDataUrl); 
	}
	
	@GetMapping("saveWorkbooks")
	public void saveWorkbooks() throws JsonMappingException, JsonProcessingException {
		HashMap<Object,Object> credentials=tableauServices.connectToTableau();		  				  
		String token=(String) credentials.get("token");
		System.out.println(token);
		String tableauWorkbooksDataUrl="https://prod-useast-a.online.tableau.com/api/3.9/sites/422cd704-a0a0-423e-b863-864a294e51d6/workbooks?pageNumber=";
		tableauServices.saveWorkbooks(token,tableauWorkbooksDataUrl);
	}
	
	/*
	 * @GetMapping("/getLoggedInUser") public String getLoggedInUser(){
	 * System.out.println(userServices.getLoggedInUser()); String
	 * userName=userServices.getLoggedInUser(); return
	 * userServices.getLoggedInUser(); }
	 * 
	 * @GetMapping("/getLoggedInUserGroup") public String getLoggedInUserGroup() {
	 * return userServices.getLoggedinUserGroup(); }
	 */
}

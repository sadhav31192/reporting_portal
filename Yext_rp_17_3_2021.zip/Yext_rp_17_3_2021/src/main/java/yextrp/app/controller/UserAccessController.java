
package yextrp.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import yextrp.app.Services.UserServices;
import yextrp.app.model.UserDetails;

/**
 * @author Vaibhav Aware
 *
 */
@CrossOrigin(origins = "*", allowedHeaders = "*") 
@RequestMapping("/user")
@RestController
public class UserAccessController {

	@Autowired
	UserServices userServices;

	@GetMapping("/getLoggedInUser")
	public UserDetails getLoggedInUser() {

		return userServices.getLoggedInUserFolders();

	}
}
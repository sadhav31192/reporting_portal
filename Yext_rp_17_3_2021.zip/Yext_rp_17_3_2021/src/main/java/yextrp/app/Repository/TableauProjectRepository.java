/**
 * @author Sandip Adhav
 */
package yextrp.app.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import yextrp.app.entity.TableauProject;

/**
 * @author Sandip Adhav
 *Repository Interface to access Tableau Projects/folders Data
 */
@Repository
public interface TableauProjectRepository extends JpaRepository<TableauProject, String >{
	/**
	 * 
	 * @param parentId
	 * @return
	 */
	@Query(value="SELECT parent_project_id  FROM  tableau_project WHERE  project_id=?1 ",nativeQuery = true)
	public String getParentProject(String parentId);
	
}

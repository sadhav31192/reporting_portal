package yextrp.app.Repository;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import yextrp.app.entity.TrainingsId;
import yextrp.app.entity.TrainingsMetadata;
import yextrp.app.entity.UserAccess;
import yextrp.app.entity.UserAccessId;
import yextrp.app.model.UserDetails;

/**
 * @author Sandip Adhav
 *
 */
@Repository
public interface UserAccessRepository extends JpaRepository<UserAccess, UserAccessId> {

	@Query(value = "SELECT folder_id FROM  reporting_portal.user_access WHERE user_id LIKE?1", nativeQuery = true)
	ArrayList<String> findUserAccess(String userId);
	
	@Query(value = "select DISTINCT folder_name FROM reporting_portal.user_access where user_id=?", nativeQuery = true)
	List<String> getLoggedInUser(String string);
}

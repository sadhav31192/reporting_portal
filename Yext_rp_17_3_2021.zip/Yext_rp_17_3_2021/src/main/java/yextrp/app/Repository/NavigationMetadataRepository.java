

/**
 * @author Sandip Adhav
 */
package yextrp.app.Repository;

import java.util.Collection;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import yextrp.app.entity.NavigationMetadata;
import yextrp.app.entity.NavigationMetdataId;
import yextrp.app.entity.ReportsMetadata;

/**
 * @author Sandip Adhav
 *
 */
@Repository
public interface NavigationMetadataRepository extends JpaRepository<NavigationMetadata,NavigationMetdataId> {
	
	@Query(value="SELECT * FROM reporting_portal.navigation_metadata  WHERE folder_id  IN ?1",nativeQuery = true)
	Collection<NavigationMetadata> findNavigationMetadata(List<String> listofFolderIds);
	
}

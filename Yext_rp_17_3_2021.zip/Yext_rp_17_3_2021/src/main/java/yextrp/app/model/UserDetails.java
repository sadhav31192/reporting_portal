/**
 * 
 */
package yextrp.app.model;

import java.util.Collection;
import java.util.List;

import javax.persistence.ElementCollection;

/**
 * @author vaibhav aware
 *
 */
public class UserDetails {
	private String userId;

	@ElementCollection
	private List<String> reportFolders;

	public UserDetails() {
		super();
	}

	/**
	 * @param userId
	 * @param reportFolders
	 */
	public UserDetails(String userId, List<String> reportFolders) {
		super();
		this.userId = userId;
		this.reportFolders = reportFolders;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public List<String> getReportFolders() {
		return reportFolders;
	}

	public void setReportFolders(List<String> reportFolders) {
		this.reportFolders = reportFolders;
	}

}
